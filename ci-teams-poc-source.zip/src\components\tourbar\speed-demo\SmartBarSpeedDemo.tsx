import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { CalendarDays, ChevronLeft, ChevronRight, Compass, RefreshCcw, Users } from "lucide-react";
import { clearSmartBarFocusOverlay, smartbarFocusTarget } from "../smartbarFocusController";
import TourBarShell, {
  type TourBarShellActions,
  type TourBarShellDemoCommand,
  type TourBarShellResult,
  type TourBarShellTurnContext,
} from "../TourBarShell";
import { OrderReview, type CarryoutLine, type CarryoutOrder, type CarryoutQualifierGroup, type CarryoutQualifierOption, type GuideAiCarryoutResponse, type ReviewItem, type ReviewMode, type TourBarOrderingFocusTarget } from "../TourBarOrdering";
import { TourBarBookingHandoffSheet, TourBarNavigationControls, type TourBarBookingHandoff, type TourBarBookingNavigationState } from "../TourBarBooking";
import TourBarAfterHoursLeadSheet from "../TourBarAfterHoursLeadSheet";
import ThinkingText from "../ThinkingText";
import SmartBarDemoScrubber from "./SmartBarDemoScrubber";
import SmartBarDemoToolbarFrame from "./SmartBarDemoToolbarFrame";
import BurgerRushMobileExperience from "../smartbar-mobile/burgerrush/BurgerRushMobileExperience";
import NexaPathMobileExperience from "../smartbar-mobile/nexapath/NexaPathMobileExperience";
import SmartBarSpeedTargetWall from "./SmartBarSpeedTargetWall";
import { SmartBarFlashCardStack, type SmartBarFlashCardStackItem } from "./SmartBarFlashCardStack";
import {
  SmartBarFakePointerOverlay,
  SMARTBAR_FAKE_POINTER_AIM_MS,
  SMARTBAR_FAKE_POINTER_EXIT_MS,
  SMARTBAR_FAKE_POINTER_PULSE_MS,
  makeSmartBarFakePointerState,
  type SmartBarFakePointerState,
} from "./SmartBarFakePointer";
import {
  SmartBarFlashCard,
  SmartBarFlashCardLane,
  SmartBarFlashCardRail,
  SMARTBAR_FLASH_CARD_TRANSITION_MS,
  SMARTBAR_FLASH_CARD_CROSSOVER_MS,
  type SmartBarFlashCardCascadeMode,
  type SmartBarFlashCardLaneName,
  type SmartBarFlashCardNotice,
  type SmartBarTutorCard,
} from "./SmartBarFlashCardRail";
import {
  SMARTBAR_BURGERRUSH_MOBILE_STEPS,
  SMARTBAR_BURGERRUSH_ONLY_STEPS,
  SMARTBAR_FOOD_TRIO_DESKTOP_STEPS,
  SMARTBAR_SPEED_STEPS,
  type SmartBarSpeedCommand,
} from "./smartBarSpeedScript";

const TYPE_DELAY_MS = 18;
const MOBILE_TYPE_DELAY_MS = 42;
const MOBILE_STAGE_SCROLL_MIN_MS = 620;
const MOBILE_STAGE_SCROLL_MAX_MS = 1480;
const MOBILE_STAGE_SCROLL_PX_FACTOR = 0.82;
const MOBILE_STAGE_TOP_ANCHOR_Y = 30;
const MOBILE_NEXT_MOVE_POINTER_EXTRA_WAIT_MS = 650;
const MOBILE_NEXT_MOVE_POINTER_PULSE_MS = 1050;
const DETERMINISTIC_FIXTURE_THINKING_MS = 280;
const TEXT_FIXTURE_THINKING_MS = 1500;
const SCRIPTED_SUBMIT_SETTLE_BUFFER_MS = 120;
const DEMO_TUTOR_INITIAL_DELAY_MS = 820;
const DEMO_TUTOR_HOLD_MS = 2500;
const DEMO_REPLAY_SETTLE_MS = 360;
const SPEED_DEMO_POINTER_SETTLE_FRAMES = 3;
const SPEED_DEMO_POINTER_STABLE_RECT_ATTEMPTS = 34;
const SPEED_DEMO_POINTER_LOCK_ATTEMPTS = 10;
const SPEED_DEMO_POINTER_MIN_VISIBLE_RATIO = 0.82;

// FLASHCARD SPEED CONTROLS
// Bigger number = slower. Smaller number = faster.
// Change these values first; leave the card/stack animation files alone unless
// you want to change the physical slide distance, overlap, or easing.
const FLASHCARD_SPEED_CONTROLS = {
  slowCascadeNextCardMs: 1000,
  slowCascadeFinalHoldMs: 1800,
  rapidCascadeNextCardMs: 500,
  rapidCascadeFinalHoldMs: 1900,
  normalCardHoldMs: DEMO_TUTOR_HOLD_MS,
} as const;

const OPENING_DEMO_TUTOR_CARDS: SmartBarTutorCard[] = [
  {
    title: "Example 1: **NexaPath Advisory**",
    cascadeGroup: "intro-3",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 1500,
  },
  {
    title: "Managed IT for finance",
    cascadeGroup: "intro-3",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 1500,
  },
  {
    title: "SmartBar generates a lead",
    cascadeGroup: "intro-3",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 1500,
    clearCascade: true,
  },
];

const BURGERRUSH_ONLY_DEMO_TUTOR_CARDS: SmartBarTutorCard[] = [];
const FOOD_TRIO_DESKTOP_OPENING_TUTOR_CARDS: SmartBarTutorCard[] = [];

type MobileBurgerRushStage = "intro" | "placement" | "demo" | "outro";

const MOBILE_BURGERRUSH_OUTRO_TUTOR_CARDS: SmartBarTutorCard[] = [
{
    title: "Words in.",
    cascadeGroup: "mobile-burger-rush-outro-1",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 900,
  },
  {
    title: "Cart out.",
    cascadeGroup: "mobile-burger-rush-outro-1",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 900,
  },
  {
    title: "Missing details?",
    cascadeGroup: "mobile-burger-rush-outro-1",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 900,
  },
  {
    title: "Color codes.",
    cascadeGroup: "mobile-burger-rush-outro-1",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 900,
  },
  {
    title: "Quick taps.",
    cascadeGroup: "mobile-burger-rush-outro-1",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 4000,
    clearCascade: true,
  },
  // {
  //   title: "Singl .",
  //   cascadeGroup: "mobile-burger-rush-outro-2",
  //   cascadeMode: "standard",
  //   density: "normal",
  //   holdMs: 900,
  // },
  // {
  //   title: "Office lunches.",
  //   cascadeGroup: "mobile-burger-rush-outro-2",
  //   cascadeMode: "standard",
  //   density: "normal",
  //   holdMs: 900,
  // },
  // {
  //   title: "Team meals.",
  //   cascadeGroup: "mobile-burger-rush-outro-2",
  //   cascadeMode: "standard",
  //   density: "normal",
  //   holdMs: 900,
  // },
  // {
  //   title: "Catering requests.",
  //   cascadeGroup: "mobile-burger-rush-outro-2",
  //   cascadeMode: "standard",
  //   density: "normal",
  //   holdMs: 900,
  // },
  // {
  //   title: "Paste the list.",
  //   cascadeGroup: "mobile-burger-rush-outro-2",
  //   cascadeMode: "standard",
  //   density: "normal",
  //   holdMs: 900,
  // },
  // {
  //   title: "Build the cart.",
  //   cascadeGroup: "mobile-burger-rush-outro-2",
  //   cascadeMode: "standard",
  //   density: "normal",
  //   holdMs: 1500,
  //   clearCascade: true,
  // },
  {
    title: "Setup is simple.",
    cascadeGroup: "mobile-burger-rush-outro-3",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 900,
  },
  {
    title: "Site scan.",
    cascadeGroup: "mobile-burger-rush-outro-3",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 900,
  },
  {
    title: "Code snippet.",
    cascadeGroup: "mobile-burger-rush-outro-3",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 900,
  },
  {
    title: "And a menu slip.",
    cascadeGroup: "mobile-burger-rush-outro-3",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 900,
  },
  {
    title: "Go live.",
    cascadeGroup: "mobile-burger-rush-outro-3",
    cascadeMode: "standard",
    density: "normal",
    holdMs: 1800,
    clearCascade: true,
  },
];

function wait(ms: number) {
  return new Promise<void>((resolve) => window.setTimeout(resolve, ms));
}

function waitForFrame() {
  return new Promise<void>((resolve) => window.requestAnimationFrame(() => resolve()));
}

function speedDemoIsPhoneViewport() {
  if (typeof window === "undefined") return false;

  return (
    window.matchMedia("(max-width: 767px)").matches ||
    /Android|iPhone|iPod|Mobile/i.test(window.navigator.userAgent)
  );
}

function speedDemoTypeDelayMs() {
  return speedDemoIsPhoneViewport() ? MOBILE_TYPE_DELAY_MS : TYPE_DELAY_MS;
}

function speedDemoIsMobileNextMovePointer(command: Extract<SmartBarSpeedCommand, { kind: "pointerClick" }>) {
  return Boolean(
    speedDemoIsPhoneViewport() &&
      command.targetSelector?.includes("data-tourbar-nextmove-query"),
  );
}

function speedDemoPointerTargetKind(target: HTMLElement) {
  return target.getAttribute("data-smartbar-pointer-kind") || "";
}

function speedDemoPointerAnchorY(
  target: HTMLElement,
  command: Extract<SmartBarSpeedCommand, { kind: "pointerClick" }>,
) {
  if (command.anchorY !== undefined) return command.anchorY;

  if (!speedDemoIsPhoneViewport()) return 0.5;

  const targetKind = speedDemoPointerTargetKind(target);

  // Small bottom-mounted phone controls need a lower visual hotspot than normal
  // content cards. The DOM center is mathematically correct, but the fake
  // pointer graphic reads high on tiny circular controls unless we bias down.
  if (targetKind === "launcher") return 0.64;
  if (targetKind === "submit") return 0.62;

  return 0.5;
}

function speedDemoPointerOffsetY(
  target: HTMLElement,
  command: Extract<SmartBarSpeedCommand, { kind: "pointerClick" }>,
) {
  const baseOffset = command.offsetY ?? 0;

  if (!speedDemoIsPhoneViewport()) return command.offsetY;

  const targetKind = speedDemoPointerTargetKind(target);

  // Keep desktop untouched. On phones, bottom-mounted controls sit visually
  // inside the browser chrome zone, so the pointer needs a tiny downward
  // correction to land center-shot on the icon face.
  if (targetKind === "launcher") return baseOffset + 8;
  if (targetKind === "submit") return baseOffset + 6;

  return command.offsetY;
}

async function waitForFrames(count: number) {
  for (let index = 0; index < count; index += 1) {
    await waitForFrame();
  }
}

function speedDemoRectDelta(a: DOMRect, b: DOMRect) {
  return Math.max(
    Math.abs(a.top - b.top),
    Math.abs(a.left - b.left),
    Math.abs(a.width - b.width),
    Math.abs(a.height - b.height),
  );
}

async function waitForSpeedDemoStableRect(element: HTMLElement, frames = SPEED_DEMO_POINTER_SETTLE_FRAMES) {
  let previousRect = element.getBoundingClientRect();

  for (let attempt = 0; attempt < SPEED_DEMO_POINTER_STABLE_RECT_ATTEMPTS; attempt += 1) {
    await waitForFrames(frames);
    const nextRect = element.getBoundingClientRect();

    if (speedDemoRectDelta(previousRect, nextRect) < 0.75) {
      return nextRect;
    }

    previousRect = nextRect;
  }

  return element.getBoundingClientRect();
}

function speedDemoIntersectionRatio(rect: DOMRect, clip: { top: number; right: number; bottom: number; left: number }) {
  const width = Math.max(0, Math.min(rect.right, clip.right) - Math.max(rect.left, clip.left));
  const height = Math.max(0, Math.min(rect.bottom, clip.bottom) - Math.max(rect.top, clip.top));
  const visibleArea = width * height;
  const totalArea = Math.max(1, rect.width * rect.height);

  return visibleArea / totalArea;
}

function speedDemoClipRectForTarget(stage: HTMLElement | null, target: HTMLElement) {
  const viewport = {
    top: 0,
    left: 0,
    right: window.innerWidth,
    bottom: window.innerHeight,
  };

  if (!stage || !stage.contains(target)) return viewport;

  const stageRect = stage.getBoundingClientRect();
  const inset = Math.min(28, Math.max(12, stageRect.height * 0.035));

  return {
    top: Math.max(viewport.top, stageRect.top + inset),
    left: Math.max(viewport.left, stageRect.left + inset),
    right: Math.min(viewport.right, stageRect.right - inset),
    bottom: Math.min(viewport.bottom, stageRect.bottom - inset),
  };
}

function speedDemoTargetIsReady(stage: HTMLElement | null, target: HTMLElement) {
  if (!speedDemoElementLooksVisible(target)) return false;

  const rect = target.getBoundingClientRect();
  const clip = speedDemoClipRectForTarget(stage, target);
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;
  const centerIsSafe = centerX >= clip.left && centerX <= clip.right && centerY >= clip.top && centerY <= clip.bottom;

  return centerIsSafe && speedDemoIntersectionRatio(rect, clip) >= SPEED_DEMO_POINTER_MIN_VISIBLE_RATIO;
}

function resetSpeedDemoStageToTop(stage: HTMLElement | null) {
  if (typeof window !== "undefined") {
    window.scrollTo({ top: 0, left: 0, behavior: "auto" });
  }

  stage?.scrollTo({ top: 0, left: 0, behavior: "auto" });
}

function speedDemoCssEscape(value: string) {
  if (typeof CSS !== "undefined" && CSS.escape) return CSS.escape(value);
  return value.replace(/["\\]/g, "\\$&");
}

function speedDemoClamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}

function speedDemoScrollEase(progress: number) {
  return progress < 0.5 ? 4 * progress * progress * progress : 1 - Math.pow(-2 * progress + 2, 3) / 2;
}

function speedDemoStageScrollDuration(distance: number) {
  if (speedDemoIsPhoneViewport()) {
    return Math.min(
      MOBILE_STAGE_SCROLL_MAX_MS,
      Math.max(MOBILE_STAGE_SCROLL_MIN_MS, Math.abs(distance) * MOBILE_STAGE_SCROLL_PX_FACTOR),
    );
  }

  return Math.min(880, Math.max(360, Math.abs(distance) * 0.46));
}

function findSpeedDemoStageTarget(stage: HTMLElement, targetId: string) {
  const escaped = speedDemoCssEscape(targetId);
  return stage.querySelector<HTMLElement>(`[data-tour-id="${escaped}"], #${escaped}`);
}

function speedDemoElementLooksVisible(element: HTMLElement | null) {
  if (!element) return false;

  const rect = element.getBoundingClientRect();
  const style = window.getComputedStyle(element);

  return (
    rect.width > 1 &&
    rect.height > 1 &&
    rect.bottom > 0 &&
    rect.right > 0 &&
    rect.top < window.innerHeight &&
    rect.left < window.innerWidth &&
    style.visibility !== "hidden" &&
    style.display !== "none" &&
    Number(style.opacity || "1") > 0.02
  );
}

function firstVisibleSpeedDemoElement(elements: HTMLElement[]) {
  return elements.find(speedDemoElementLooksVisible) || elements[0] || null;
}

function findSpeedDemoPointerTarget(
  stage: HTMLElement | null,
  targetId?: string,
  targetSelector?: string,
) {
  if (targetSelector) {
    const stageMatches = stage ? Array.from(stage.querySelectorAll<HTMLElement>(targetSelector)) : [];
    const documentMatches = Array.from(document.querySelectorAll<HTMLElement>(targetSelector));
    return firstVisibleSpeedDemoElement([...stageMatches, ...documentMatches]);
  }

  if (!targetId) return null;

  const escaped = speedDemoCssEscape(targetId);
  const selector = `[data-tour-id="${escaped}"], #${escaped}`;
  const stageMatches = stage ? Array.from(stage.querySelectorAll<HTMLElement>(selector)) : [];
  const documentMatches = Array.from(document.querySelectorAll<HTMLElement>(selector));

  return firstVisibleSpeedDemoElement([...stageMatches, ...documentMatches]);
}

async function scrollSpeedDemoStageElementIntoView(stage: HTMLElement, target: HTMLElement) {
  await waitForFrame();

  const stageRect = stage.getBoundingClientRect();
  const targetRect = target.getBoundingClientRect();
  const targetTopInStage = stage.scrollTop + targetRect.top - stageRect.top;
  const maxTop = Math.max(0, stage.scrollHeight - stage.clientHeight);
  const safeInset = Math.min(140, Math.max(72, stage.clientHeight * 0.16));
  const availableHeight = Math.max(180, stage.clientHeight - safeInset * 2);
  const mobileTopAnchorY = Math.min(
    MOBILE_STAGE_TOP_ANCHOR_Y,
    Math.max(16, stage.clientHeight - 180),
  );
  const desiredTop = speedDemoIsPhoneViewport()
    ? targetTopInStage - mobileTopAnchorY
    : targetRect.height >= availableHeight
      ? targetTopInStage - safeInset
      : targetTopInStage - (safeInset + (availableHeight - targetRect.height) / 2);
  const startTop = stage.scrollTop;
  const endTop = speedDemoClamp(desiredTop, 0, maxTop);
  const distance = endTop - startTop;

  if (Math.abs(distance) < 2) {
    stage.scrollTo({ top: endTop, behavior: "auto" });
    await waitForFrame();
    return target;
  }

  const duration = speedDemoStageScrollDuration(distance);
  const startedAt = performance.now();

  await new Promise<void>((resolve) => {
    const step = (now: number) => {
      const progress = Math.min(1, Math.max(0, (now - startedAt) / duration));
      const eased = speedDemoScrollEase(progress);
      stage.scrollTo({ top: speedDemoClamp(startTop + distance * eased, 0, maxTop), behavior: "auto" });

      if (progress >= 1) {
        stage.scrollTo({ top: endTop, behavior: "auto" });
        resolve();
        return;
      }

      window.requestAnimationFrame(step);
    };

    window.requestAnimationFrame(step);
  });

  await waitForFrame();
  return target;
}

async function scrollSpeedDemoStageToTarget(stage: HTMLElement, targetId: string) {
  const target = findSpeedDemoStageTarget(stage, targetId);
  if (!target) return null;

  return scrollSpeedDemoStageElementIntoView(stage, target);
}

function speedDemoScrollableAncestor(target: HTMLElement) {
  let node = target.parentElement;

  while (node && node !== document.body && node !== document.documentElement) {
    const style = window.getComputedStyle(node);
    const canScrollY = /(auto|scroll)/.test(style.overflowY || "");

    if (canScrollY && node.scrollHeight > node.clientHeight + 2) {
      return node;
    }

    node = node.parentElement;
  }

  return null;
}

async function scrollSpeedDemoOverflowAncestorToTarget(target: HTMLElement) {
  const scroller = speedDemoScrollableAncestor(target);
  if (!scroller) return;

  await waitForFrame();

  const scrollerRect = scroller.getBoundingClientRect();
  const targetRect = target.getBoundingClientRect();
  const targetTopInScroller = scroller.scrollTop + targetRect.top - scrollerRect.top;
  const safeInset = Math.min(28, Math.max(12, scroller.clientHeight * 0.08));
  const desiredTop = targetTopInScroller - safeInset;
  const maxTop = Math.max(0, scroller.scrollHeight - scroller.clientHeight);

  scroller.scrollTo({ top: speedDemoClamp(desiredTop, 0, maxTop), behavior: "auto" });
  await waitForFrame();
}

async function lockSpeedDemoPointerTarget(
  stage: HTMLElement | null,
  command: Extract<SmartBarSpeedCommand, { kind: "pointerClick" }>,
  cancelled: () => boolean,
) {
  let target: HTMLElement | null = null;

  for (let attempt = 0; attempt < SPEED_DEMO_POINTER_LOCK_ATTEMPTS; attempt += 1) {
    if (command.targetId && stage) {
      target = await scrollSpeedDemoStageToTarget(stage, command.targetId);
    }

    if (cancelled()) return null;

    target = target || findSpeedDemoPointerTarget(stage, command.targetId, command.targetSelector);

    if (target && stage?.contains(target)) {
      await scrollSpeedDemoStageElementIntoView(stage, target);
    }

    if (target) {
      await scrollSpeedDemoOverflowAncestorToTarget(target);
    }

    if (cancelled()) return null;

    if (target) {
      await waitForSpeedDemoStableRect(target);
      if (cancelled()) return null;

      if (speedDemoTargetIsReady(stage, target)) {
        return target;
      }
    }

    target = null;
    await wait(90);
  }

  return findSpeedDemoPointerTarget(stage, command.targetId, command.targetSelector);
}

function line(id: string, title: string, priceLabel: string, knownSelections: string[] = []) {
  return {
    lineItemId: id,
    id,
    title,
    quantity: 1,
    priceLabel,
    status: "ready",
    knownSelections,
  };
}

function readyCarryoutOrder(kind: "messy" | "qualified" | "finale" = "messy"): CarryoutOrder {
  if (kind === "qualified") {
    const items = [
      line("burger-combo", "Burger combo meal", "$10.99", ["Double patty", "Large fries", "Diet Coke"]),
    ];

    return {
      type: "carryout_order",
      status: "ready_cart",
      nextAction: "show_cart",
      items,
      completeItems: items,
      pendingItems: [],
      totals: {
        status: "ready",
        subtotal: 10.99,
        estimatedTax: 0.88,
        estimatedTotal: 11.87,
        currency: "USD",
      },
    };
  }

  const comboSelections = ["Large fries", "Large Diet Coke", "No onions"];
  const items = [
    line("double-cheeseburger-combo", "Double cheeseburger combo", "$11.99", comboSelections),
    line("apple-pie", "Apple pie", "$2.49"),
    ...(kind === "finale" ? [] : [line("large-diet-coke", "Large Diet Coke", "$2.19")]),
  ];

  return {
    type: "carryout_order",
    status: "ready_cart",
    nextAction: "show_cart",
    items,
    completeItems: items,
    pendingItems: [],
    totals: {
      status: "ready",
      subtotal: kind === "finale" ? 14.48 : 16.67,
      estimatedTax: kind === "finale" ? 1.16 : 1.33,
      estimatedTotal: kind === "finale" ? 15.64 : 18.0,
      currency: "USD",
    },
  };
}

function lockedCarryoutOrder(kind: "messy" | "qualified" | "finale" = "messy"): CarryoutOrder {
  const order = readyCarryoutOrder(kind);
  return {
    ...order,
    nextAction: "checkout_handoff",
    lockedForHandoff: true,
    handoffStatus: "ready",
  };
}

function pendingCarryoutOrder(stage: 0 | 1 | 2): CarryoutOrder {
  const burgerReady = stage >= 1;
  const friesReady = stage >= 2;

  const burger = {
    lineItemId: "burger-combo",
    id: "burger-combo",
    title: "Burger combo meal",
    quantity: 1,
    priceLabel: burgerReady ? "$10.99" : undefined,
    status: burgerReady ? "ready" : "needs_qualifier",
    knownSelections: burgerReady ? ["Double patty"] : [],
    missingQualifiers: burgerReady ? [] : [{ qualifierId: "patty", label: "Patty" }],
    qualifierGroups: burgerReady
      ? []
      : [
          {
            qualifierId: "patty",
            label: "Choose burger size",
            required: true,
            missing: true,
            options: [
              { label: "Single patty", value: "single" },
              { label: "Double patty", value: "double" },
              { label: "Triple patty", value: "triple" },
            ],
          },
        ],
  };

  const fries = {
    lineItemId: "fries-size",
    id: "fries-size",
    title: "Fries",
    quantity: 1,
    priceLabel: friesReady ? "$3.49" : undefined,
    status: friesReady ? "ready" : "needs_qualifier",
    knownSelections: friesReady ? ["Large fries"] : [],
    missingQualifiers: friesReady ? [] : [{ qualifierId: "fries", label: "Fries size" }],
    qualifierGroups: friesReady
      ? []
      : [
          {
            qualifierId: "fries",
            label: "Choose fries",
            required: true,
            missing: true,
            options: [
              { label: "Small fries", value: "small" },
              { label: "Medium fries", value: "medium" },
              { label: "Large fries", value: "large" },
            ],
          },
        ],
  };

  const drink = {
    lineItemId: "drink-choice",
    id: "drink-choice",
    title: "Drink",
    quantity: 1,
    priceLabel: undefined,
    status: "needs_qualifier",
    knownSelections: [],
    missingQualifiers: [{ qualifierId: "drink", label: "Drink" }],
    qualifierGroups: [
      {
        qualifierId: "drink",
        label: "Choose drink",
        required: true,
        missing: true,
        options: [
          { label: "Coke", value: "coke" },
          { label: "Diet Coke", value: "diet-coke" },
          { label: "Sprite", value: "sprite" },
        ],
      },
    ],
  };

  const items = [burger, fries, drink];
  return {
    type: "carryout_order",
    status: "needs_qualifier",
    nextAction: "choose_qualifier",
    items,
    completeItems: items.filter((item) => item.status === "ready"),
    pendingItems: items.filter((item) => item.status !== "ready"),
    currentStep: {
      type: "qualifier",
      itemId: stage === 0 ? "burger-combo" : stage === 1 ? "fries-size" : "drink-choice",
      qualifierId: stage === 0 ? "patty" : stage === 1 ? "fries" : "drink",
      question: stage === 0 ? "Choose burger size" : stage === 1 ? "Choose fries" : "Choose drink",
    },
    totals: {
      status: "partial",
      subtotal: stage === 0 ? null : stage === 1 ? 10.99 : 14.48,
      estimatedTax: null,
      estimatedTotal: null,
      currency: "USD",
    },
  };
}


function readyCheeseburgerFriesShakeOrder(): CarryoutOrder {
  // TourBarOrdering reverses backend-style cart lines into the visible review
  // order. Keep fixture lines in backend order so the review steps land as:
  // 1) Cheeseburger, 2) Fries, 3) Milkshake.
  const items = [
    line("milkshake", "Milkshake", "$4.29", ["Chocolate"]),
    line("fries-size", "Fries", "$3.49", ["Large fries"]),
    line("cheeseburger", "Cheeseburger", "$5.49", ["No onions"]),
  ].map((item) => {
    if (item.id === "cheeseburger") return { ...item, targetId: "item-cheeseburger" };
    if (item.id === "fries-size") return { ...item, targetId: "side-fries" };
    return { ...item, targetId: "drink-milkshake" };
  });

  return {
    type: "carryout_order",
    status: "ready_cart",
    nextAction: "show_cart",
    items,
    completeItems: items,
    pendingItems: [],
    totals: {
      status: "ready",
      subtotal: 13.27,
      estimatedTax: 1.06,
      estimatedTotal: 14.33,
      currency: "USD",
    },
  };
}

function lockedCheeseburgerFriesShakeOrder(): CarryoutOrder {
  return {
    ...readyCheeseburgerFriesShakeOrder(),
    nextAction: "checkout_handoff",
    lockedForHandoff: true,
    handoffStatus: "ready",
  };
}

function optionalCheeseburgerOrder(kind: "plain" | "bacon" = "plain"): CarryoutOrder {
  const hasBacon = kind === "bacon";
  const subtotal = hasBacon ? 6.74 : 5.49;
  const item = {
    lineItemId: "cheeseburger-options",
    id: "item-cheeseburger",
    targetId: "item-cheeseburger",
    title: "Cheeseburger",
    quantity: 1,
    priceLabel: `$${subtotal.toFixed(2)}`,
    status: "ready",
    knownSelections: ["No onions"],
    modifiers: hasBacon ? [{ label: "Bacon", priceDelta: 1.25 }] : [],
    qualifierGroups: [
      {
        kind: "modifier",
        qualifierId: "burger-extras",
        label: "Optional extras",
        targetId: "item-cheeseburger",
        required: false,
        missing: false,
        selectionMode: "multi",
        options: [
          { label: "Bacon", value: "bacon", priceDelta: 1.25 },
          { label: "Extra sauce", value: "extra-sauce", priceDelta: 0.5 },
          { label: "Pickles", value: "pickles", priceDelta: 0 },
        ],
      },
    ],
  };

  const items = [item];
  return {
    type: "carryout_order",
    status: "ready_cart",
    nextAction: "show_cart",
    items,
    completeItems: items,
    pendingItems: [],
    totals: {
      status: "ready",
      subtotal,
      estimatedTax: hasBacon ? 0.54 : 0.44,
      estimatedTotal: hasBacon ? 7.28 : 5.93,
      currency: "USD",
    },
  };
}

function lockedOptionalCheeseburgerOrder(): CarryoutOrder {
  return {
    ...optionalCheeseburgerOrder("bacon"),
    nextAction: "checkout_handoff",
    lockedForHandoff: true,
    handoffStatus: "ready",
  };
}

function cannotMatchTacoOrder(): CarryoutOrder {
  const items = [
    line("fries-size", "Fries", "$3.49", ["Large fries"]),
    line("cheeseburger", "Cheeseburger", "$5.49", ["No onions"]),
  ].map((item) => {
    if (item.id === "cheeseburger") return { ...item, targetId: "item-cheeseburger" };
    return { ...item, targetId: "side-fries" };
  });

  return {
    type: "carryout_order",
    status: "partial_match",
    nextAction: "show_cart",
    items,
    completeItems: items,
    pendingItems: [],
    cannotMatchItems: [
      {
        text: "lava tacos",
        reason: "not_on_menu",
      },
    ],
    totals: {
      status: "partial",
      subtotal: 8.98,
      estimatedTax: 0.72,
      estimatedTotal: 9.7,
      currency: "USD",
    },
  };
}

function retriedMediumOnionRingsOrder(): CarryoutOrder {
  const items = [
    line("medium-onion-rings", "Medium onion rings", "$3.99", ["Medium"]),
    line("fries-size", "Fries", "$3.49", ["Large fries"]),
    line("cheeseburger", "Cheeseburger", "$5.49", ["No onions"]),
  ].map((item) => {
    if (item.id === "cheeseburger") return { ...item, targetId: "item-cheeseburger" };
    if (item.id === "fries-size") return { ...item, targetId: "side-fries" };
    return { ...item, targetId: "side-onion-rings" };
  });

  return {
    type: "carryout_order",
    status: "ready_cart",
    nextAction: "show_cart",
    items,
    completeItems: items,
    pendingItems: [],
    cannotMatchItems: [],
    totals: {
      status: "ready",
      subtotal: 12.97,
      estimatedTax: 1.04,
      estimatedTotal: 14.01,
      currency: "USD",
    },
  };
}

function pendingCheeseburgerFriesShakeOrder(stage: 0 | 1 | 2): CarryoutOrder {
  const cheeseburgerReady = stage >= 1;
  const friesReady = stage >= 2;

  const cheeseburger = {
    lineItemId: "cheeseburger",
    id: "item-cheeseburger",
    targetId: "item-cheeseburger",
    title: "Cheeseburger",
    quantity: 1,
    priceLabel: cheeseburgerReady ? "$5.49" : undefined,
    status: cheeseburgerReady ? "ready" : "needs_qualifier",
    knownSelections: cheeseburgerReady ? ["No onions"] : [],
    missingQualifiers: cheeseburgerReady ? [] : [{ qualifierId: "burger-setup", label: "Burger setup", targetId: "item-cheeseburger" }],
    qualifierGroups: cheeseburgerReady
      ? []
      : [
          {
            qualifierId: "burger-setup",
            label: "Choose burger setup",
            targetId: "item-cheeseburger",
            required: true,
            missing: true,
            options: [
              { label: "No onions", value: "no-onions" },
              { label: "No pickles", value: "no-pickles" },
              { label: "Extra sauce", value: "extra-sauce" },
            ],
          },
        ],
  };

  const fries = {
    lineItemId: "fries-size",
    id: "fries-size",
    targetId: "side-fries",
    title: "Fries",
    quantity: 1,
    priceLabel: friesReady ? "$3.49" : undefined,
    status: friesReady ? "ready" : "needs_qualifier",
    knownSelections: friesReady ? ["Large fries"] : [],
    missingQualifiers: friesReady ? [] : [{ qualifierId: "fries", label: "Fries size", targetId: "side-fries" }],
    qualifierGroups: friesReady
      ? []
      : [
          {
            qualifierId: "fries",
            label: "Choose fries",
            targetId: "side-fries",
            required: true,
            missing: true,
            options: [
              { label: "Small fries", value: "small" },
              { label: "Medium fries", value: "medium" },
              { label: "Large fries", value: "large" },
            ],
          },
        ],
  };

  const milkshake = {
    lineItemId: "milkshake",
    id: "milkshake",
    targetId: "drink-milkshake",
    title: "Milkshake",
    quantity: 1,
    priceLabel: undefined,
    status: "needs_qualifier",
    knownSelections: [],
    missingQualifiers: [{ qualifierId: "milkshake-flavor", label: "Milkshake flavor", targetId: "drink-milkshake" }],
    qualifierGroups: [
      {
        qualifierId: "milkshake-flavor",
        label: "Choose milkshake flavor",
        targetId: "drink-milkshake",
        required: true,
        missing: true,
        options: [
          { label: "Vanilla", value: "vanilla" },
          { label: "Chocolate", value: "chocolate" },
          { label: "Strawberry", value: "strawberry" },
        ],
      },
    ],
  };

  // Backend-style order is reversed by TourBarOrdering into the visible review
  // sequence. This preserves the visible steps as cheeseburger → fries → milkshake.
  const items = [milkshake, fries, cheeseburger];

  return {
    type: "carryout_order",
    status: "needs_qualifier",
    nextAction: "choose_qualifier",
    items,
    completeItems: items.filter((item) => item.status === "ready"),
    pendingItems: items.filter((item) => item.status !== "ready"),
    currentStep: {
      type: "qualifier",
      itemId: stage === 0 ? "cheeseburger" : stage === 1 ? "fries-size" : "milkshake",
      targetId: stage === 0 ? "item-cheeseburger" : stage === 1 ? "side-fries" : "drink-milkshake",
      qualifierId: stage === 0 ? "burger-setup" : stage === 1 ? "fries" : "milkshake-flavor",
      question: stage === 0 ? "Choose burger setup" : stage === 1 ? "Choose fries" : "Choose milkshake flavor",
    },
    totals: {
      status: "partial",
      subtotal: stage === 0 ? null : stage === 1 ? 5.49 : 8.98,
      estimatedTax: null,
      estimatedTotal: null,
      currency: "USD",
    },
  };
}

function carryoutRaw(order: CarryoutOrder, commerceAction = "carryout_show_cart"): GuideAiCarryoutResponse {
  return {
    title: order.status === "ready_cart" ? "Review order" : "Needs choices",
    body: order.status === "ready_cart" ? "Review the cart before checkout." : "Pick the missing choices.",
    commerceAction,
    displayMode: order.status === "ready_cart" ? "carryout_cart_panel" : "carryout_review",
    carryoutOrder: order,
    visibleContext: { carryoutOrder: order },
  };
}

type SpeedResultOptions = {
  title?: string;
  body?: string;
  activeIndex?: number;
  reviewMode?: ReviewMode;
  nextQuery?: string;
  keepSheetOpenNextMove?: boolean;
  separateSheetNextMove?: boolean;
  stableSheetKey?: string;
  commerceAction?: string;
  promoteReadyLineItemId?: string;
  focusTargetId?: string;
  nextMoveLoadingMessage?: string;
};

function speedMeta(
  options: {
    keepSheetOpenNextMove?: boolean;
    separateSheetNextMove?: boolean;
    stableSheetKey?: string;
    readyPillLabel?: string;
    thinkingOnNextMove?: boolean;
    nextMoveLoadingMessage?: string;
  } = {},
) {
  return {
    __speedDemo: {
      keepSheetOpenNextMove: Boolean(options.keepSheetOpenNextMove),
      separateSheetNextMove: Boolean(options.separateSheetNextMove),
      stableSheetKey: options.stableSheetKey,
      readyPillLabel: options.readyPillLabel,
      thinkingOnNextMove: Boolean(options.thinkingOnNextMove),
      nextMoveLoadingMessage: options.nextMoveLoadingMessage,
    },
  };
}

function speedDemoCompactText(value?: string | null) {
  return String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
}

function speedDemoQueryLooksInternal(value?: string | null) {
  return speedDemoCompactText(value).startsWith("__");
}

function speedOrderResultAllowsThinkingTheater(
  result: TourBarShellResult,
  query?: string | null,
) {
  if (result.mode !== "speed_order") return false;

  // BurgerRush has two kinds of speed_order moments:
  // - visitor prompt -> structured order/cart result, which should get a brief
  //   ThinkingText beat before the sheet opens
  // - deterministic next-move steps like __checkout_* / __qualifier_*, which
  //   should stay fast and not add theater
  return !speedDemoQueryLooksInternal(query);
}

function speedResultAllowsThinkingTheater(
  result: TourBarShellResult,
  query?: string | null,
) {
  return (
    [
      "speed_info",
      "speed_case_studies",
      "speed_booking_reco",
      "speed_package",
      "speed_family_reco",
    ].includes(result.mode || "") ||
    speedOrderResultAllowsThinkingTheater(result, query)
  );
}

function speedDemoLooksLikeConsultantRequest(value?: string | null) {
  const text = speedDemoCompactText(value);
  if (!text) return false;

  return /\b(talk|speak|chat|connect|contact|call|reach)\b/.test(text) &&
    /\b(consultant|specialist|advisor|adviser|expert|sales|someone|person|human|representative|rep|team)\b/.test(text);
}

function speedDemoFixtureThinkingMs(
  result: TourBarShellResult,
  query?: string | null,
) {
  return speedResultAllowsThinkingTheater(result, query)
    ? TEXT_FIXTURE_THINKING_MS
    : DETERMINISTIC_FIXTURE_THINKING_MS;
}

function speedDemoFixtureThinkingMsForQuery(query: string) {
  if (speedDemoLooksLikeConsultantRequest(query)) return 0;

  const result = fixtureResult(query);
  return speedDemoFixtureThinkingMs(result, query);
}

function orderResult(order: CarryoutOrder, options: SpeedResultOptions = {}): TourBarShellResult {
  const raw = carryoutRaw(order, options.commerceAction || "carryout_show_cart");
  return {
    title: options.title || (order.status === "ready_cart" ? "Review order" : "Choose required options"),
    body: options.body ?? (order.status === "ready_cart" ? undefined : "Select the missing choice."),
    invitation: options.nextQuery ? { kind: "next", text: options.nextQuery.startsWith("__checkout") ? "Checkout" : "Choose this option" } : undefined,
    nextMove: options.nextQuery ? { type: "handoff", label: options.nextQuery.startsWith("__checkout") ? "Checkout" : "Choose this option", query: options.nextQuery } : undefined,
    canFollowUp: !order.lockedForHandoff,
    mode: "speed_order",
    action: raw.commerceAction,
    raw: {
      ...raw,
      __speedDemo: {
        activeIndex: options.activeIndex || 0,
        reviewMode: options.reviewMode || (order.status === "ready_cart" ? "cart" : "review"),
        keepSheetOpenNextMove: Boolean(options.keepSheetOpenNextMove),
        separateSheetNextMove: Boolean(options.separateSheetNextMove),
        stableSheetKey: options.stableSheetKey || "ordering",
        readyPillLabel: order.status === "ready_cart" ? "All items are ready for checkout" : undefined,
        promoteReadyLineItemId: options.promoteReadyLineItemId,
        focusTargetId: options.focusTargetId,
        nextMoveLoadingMessage: options.nextMoveLoadingMessage,
      },
    },
  };
}


function bookingHandoff(kind: "ocean" | "family"): TourBarBookingHandoff {
  if (kind === "family") {
    return {
      roomTitle: "Family Double Room",
      packageTitle: "Family Comfort Bundle",
      datesLabel: "Jun 12–15, 2026",
      guestsLabel: "2 adults, 2 children",
      budgetLabel: "Family value",
      priceLabel: "$249/night + $55/stay",
    };
  }

  return {
    roomTitle: "Ocean View Suite",
    packageTitle: "Breakfast Flex Plan",
    datesLabel: "Aug 4–9, 2026",
    guestsLabel: "1 guest",
    budgetLabel: "Good view, not villa tier",
    priceLabel: "$379/night + $32/night",
  };
}


// FoodTrio desktop fixtures: desktop-adapted from the mobile FoodTrio source of truth.
function foodTrioSlug(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "") || "choice";
}

function foodTrioOptionLabels(labels: string[]) {
  return labels.map((label) => ({ label, value: foodTrioSlug(label) }));
}

function foodTrioReadyLine(
  id: string,
  targetId: string,
  title: string,
  priceLabel: string,
  knownSelections: string[] = [],
  options: string[] = [],
  selectionMode: "single" | "multi" = "multi",
) {
  return {
    lineItemId: id,
    id,
    targetId,
    title,
    quantity: 1,
    priceLabel,
    status: "ready",
    knownSelections,
    qualifierGroups: options.length
      ? [
          {
            kind: "modifier",
            qualifierId: `${id}-options`,
            label: "Optional edits",
            targetId,
            required: false,
            missing: false,
            selectionMode,
            options: foodTrioOptionLabels(options),
          },
        ]
      : [],
  };
}

function foodTrioRequiredLine(
  id: string,
  targetId: string,
  title: string,
  priceLabel: string | undefined,
  knownSelections: string[],
  qualifierLabel: string,
  options: string[],
) {
  return {
    lineItemId: id,
    id,
    targetId,
    title,
    quantity: 1,
    priceLabel,
    status: "needs_qualifier",
    knownSelections,
    missingQualifiers: [{ qualifierId: `${id}-required`, label: qualifierLabel, targetId }],
    qualifierGroups: [
      {
        qualifierId: `${id}-required`,
        label: qualifierLabel,
        targetId,
        required: true,
        missing: true,
        options: foodTrioOptionLabels(options),
      },
    ],
  };
}

function foodTrioCoffeeOrder(): CarryoutOrder {
  const items = [
    foodTrioReadyLine(
      "coffee-cold-brew",
      "foodtrio-coffee-cold-brew",
      "Cold Brew",
      "$6.25",
      ["Black", "Vanilla cold foam"],
      ["Extra cold foam", "Splash oat milk", "Light ice", "No sweetener"],
    ),
    foodTrioReadyLine(
      "coffee-matcha-latte",
      "foodtrio-coffee-cappuccino",
      "Matcha Latte",
      "$6.95",
      ["Almond milk", "No foam", "Light ice"],
      ["Extra matcha", "Less sweet", "Oat milk"],
    ),
    foodTrioReadyLine(
      "coffee-iced-vanilla-latte",
      "foodtrio-coffee-iced-vanilla-latte",
      "Iced Vanilla Latte",
      "$7.25",
      ["Oat milk", "Half sweet", "Light ice", "Extra shot"],
      ["Vanilla cold foam", "Caramel drizzle", "Extra vanilla"],
    ),
  ];

  return {
    type: "carryout_order",
    status: "ready_cart",
    nextAction: "show_cart",
    items,
    completeItems: items,
    pendingItems: [],
    totals: {
      status: "ready",
      subtotal: 20.45,
      estimatedTax: 1.64,
      estimatedTotal: 22.09,
      currency: "USD",
    },
  };
}

function foodTrioFastFoodOrder(): CarryoutOrder {
  // FOODTRIO_FAST_FOOD_GREEN_FOCUS_STORY:
  // Fast food proves messy shorthand becomes a mostly-ready green cart.
  // Prompt: "2 chick mals, 1 spicy, both diet coke, 6 kids nug bbq sauce, extra sauces, crunch wrap"
  const spicyMeal = foodTrioReadyLine(
    "fast-spicy-meal",
    "foodtrio-fast-spicy-sandwich-meal",
    "1 × Spicy Chicken Sandwich Meal",
    "$10.99",
    ["Medium fries", "Diet Coke"],
  );
  const mildMeal = foodTrioReadyLine(
    "fast-mild-meal",
    "foodtrio-fast-original-sandwich-meal",
    "1 × Mild Chicken Sandwich Meal",
    "$10.49",
    ["Medium fries", "Diet Coke"],
  );
  const kidsNuggets = foodTrioReadyLine(
    "fast-kids-nuggets",
    "foodtrio-fast-nuggets",
    "Kids Nuggets",
    "$5.99",
    ["6-count", "BBQ sauce"],
  );
  const sauces = foodTrioReadyLine(
    "fast-sauces",
    "foodtrio-fast-sauces",
    "Sauce bundle",
    "$0.00",
    ["BBQ"],
    ["Ranch", "Buffalo", "Honey mustard", "Extra BBQ"],
  );
  // Order is intentionally bottom-to-top for the desktop cart renderer:
  // visual top after gray retry row should read spicy, mild, kids, sauces.
  const items = [sauces, kidsNuggets, mildMeal, spicyMeal];

  return {
    type: "carryout_order",
    status: "partial_match",
    nextAction: "show_cart",
    items,
    completeItems: items,
    pendingItems: [],
    cannotMatchItems: [
      {
        text: "crunch wrap",
        reason: "not_on_menu",
      },
    ],
    totals: {
      status: "partial",
      subtotal: 27.47,
      estimatedTax: null,
      estimatedTotal: null,
      currency: "USD",
    },
  };
}

function foodTrioCasualDiningOrder(finalReady = false): CarryoutOrder {
  const avocadoRolls = foodTrioReadyLine(
    "casual-avocado-rolls",
    "foodtrio-casual-avocado-rolls",
    "Avocado Eggrolls",
    "$14.95",
    ["Share plate", "Tamarind sauce"],
  );
  const salads = foodTrioReadyLine(
    "casual-salads",
    "foodtrio-casual-dinner-salad",
    "2 × Dinner Salads",
    "$17.90",
    ["One ranch", "One vinaigrette"],
  );
  // FOODTRIO_CASUAL_MADEIRA_GREEN_EDITABLE:
  // Madeira is green because "with mashed potatoes" was captured on first pass.
  // The side choices remain available so the demo can reopen a green tile and change it.
  const madeira = foodTrioReadyLine(
    "casual-madeira",
    "foodtrio-casual-chicken-madeira",
    "Chicken Madeira",
    "$24.95",
    ["Mashed potatoes"],
    [
      "Asparagus",
      "Rice pilaf",
      "Side salad",
      // FOODTRIO_MADEIRA_KEEP_MASHED_OPTION:
      // Mashed potatoes must remain in the option list after it is deselected.
      "Mashed potatoes",
    ],
  );
  const salmon = finalReady
    ? foodTrioReadyLine(
        "casual-salmon",
        "foodtrio-casual-herb-salmon",
        "Herb-Crusted Salmon",
        "$27.95",
        ["Asparagus"],
        ["Rice pilaf", "Mashed potatoes", "Side salad"],
      )
    : foodTrioRequiredLine(
        "casual-salmon",
        "foodtrio-casual-herb-salmon",
        "Herb-Crusted Salmon",
        undefined,
        [],
        "Choose entree side",
        ["Asparagus", "Rice pilaf", "Mashed potatoes", "Side salad"],
      );
  // FOODTRIO_CASUAL_CLEAN_BEAT_STORY:
  // Extra whipped cream is already captured from the prompt, so the demo reviews it instead of clicking it.
  const cheesecake = foodTrioReadyLine(
    "casual-cheesecake",
    "foodtrio-casual-cheesecake",
    "Original Cheesecake",
    "$10.50",
    ["Whipped cream", "Extra whipped cream"],
    ["Extra whipped cream", "No whipped cream", "Strawberry sauce"],
  );
  // Backend-style order is reversed by TourBarOrdering into the visible cart:
  // Avocado Eggrolls → Dinner Salads → Salmon → Madeira → Cheesecake.
  const items = [cheesecake, madeira, salmon, salads, avocadoRolls];

  return {
    type: "carryout_order",
    status: finalReady ? "ready_cart" : "needs_qualifier",
    nextAction: finalReady ? "show_cart" : "choose_qualifier",
    items,
    completeItems: items.filter((item) => item.status === "ready"),
    pendingItems: items.filter((item) => item.status !== "ready"),
    ...(finalReady
      ? {}
      : {
          currentStep: {
            type: "qualifier",
            itemId: "casual-salmon",
            targetId: "foodtrio-casual-herb-salmon",
            qualifierId: "casual-salmon-required",
            question: "Choose entree side",
          },
        }),
    totals: {
      status: finalReady ? "ready" : "partial",
      subtotal: finalReady ? 96.25 : 68.30,
      estimatedTax: finalReady ? 7.70 : null,
      estimatedTotal: finalReady ? 103.95 : null,
      currency: "USD",
    },
  };
}

function lockedFoodTrioCasualDiningOrder(): CarryoutOrder {
  return {
    ...foodTrioCasualDiningOrder(true),
    nextAction: "checkout_handoff",
    lockedForHandoff: true,
    handoffStatus: "ready",
  };
}

// FoodTrio desktop rebuild: use the same simple fixture checkout pattern as the
// working desktop demos. Checkout is a scripted fixture handoff per order, not
// derived from the live cart mutation path.
function lockedFoodTrioOrder(order: CarryoutOrder): CarryoutOrder {
  const normalized = speedDemoNormalizeFoodTrioOrder(order) || order;
  const items = Array.isArray(normalized.items)
    ? normalized.items
    : [...(normalized.completeItems || []), ...(normalized.pendingItems || [])];

  return {
    ...normalized,
    status: "ready_cart",
    nextAction: "checkout_handoff",
    lockedForHandoff: true,
    handoffStatus: "ready",
    items,
    completeItems: items,
    pendingItems: [],
    cannotMatchItems: [],
    totals: {
      ...(normalized.totals || {}),
      status: "ready",
    },
  };
}

function lockedFoodTrioCoffeeOrder(): CarryoutOrder {
  return lockedFoodTrioOrder(foodTrioCoffeeOrder());
}

function lockedFoodTrioFastFoodOrder(): CarryoutOrder {
  const resolvedOrder = speedDemoBuildFoodTrioSnapshotOrder(
    foodTrioFastFoodOrder(),
    "fast-sauces",
  ) || foodTrioFastFoodOrder();
  const withRetry = speedDemoReplaceCannotMatchItem(resolvedOrder, 0, "Crispy chicken wrap") || resolvedOrder;
  return lockedFoodTrioOrder(withRetry);
}

function foodTrioQueryIsCoffee(text: string) {
  return /\b(coffee|latte|matcha|cold brew|espresso|oat milk|almond milk|vanilla cold foam|three drinks)\b/.test(text);
}

function foodTrioQueryIsFastFood(text: string) {
  return /\b(chx|chick|mals?|sandwch|nug|nugs|sauce|sauces|diet coke|coke|wrap|spicy|mild)\b/.test(text);
}

function foodTrioQueryIsCasualDining(text: string) {
  return /\b(eggrolls?|salads?|salmon|madeira|cheesecake|whipped cream|appetizer|entree|dinner salads?)\b/.test(text);
}

function fixtureResult(query: string): TourBarShellResult {
  const text = query.trim().toLowerCase();

  if (text === "__checkout_foodtrio_coffee") {
    return orderResult(lockedFoodTrioCoffeeOrder(), {
      title: "Beanstack Coffee order locked for handoff",
      reviewMode: "cart",
      stableSheetKey: "foodtrio-coffee-checkout",
      commerceAction: "carryout_checkout_handoff",
      focusTargetId: "foodtrio-coffee-iced-vanilla-latte",
    });
  }

  if (text === "__checkout_foodtrio_fast_food") {
    return orderResult(lockedFoodTrioFastFoodOrder(), {
      title: "Cluck & Fry order locked for handoff",
      reviewMode: "cart",
      stableSheetKey: "foodtrio-fast-food-checkout",
      commerceAction: "carryout_checkout_handoff",
      focusTargetId: "foodtrio-fast-crispy-wrap",
    });
  }

  if (text === "__checkout_foodtrio" || text === "__checkout_foodtrio_casual") {
    return orderResult(lockedFoodTrioCasualDiningOrder(), {
      title: "Tablehouse Grill order locked for handoff",
      reviewMode: "cart",
      stableSheetKey: "foodtrio-casual-checkout",
      commerceAction: "carryout_checkout_handoff",
      focusTargetId: "foodtrio-casual-cheesecake",
    });
  }

  if (foodTrioQueryIsCoffee(text)) {
    return orderResult(foodTrioCoffeeOrder(), {
      title: "Beanstack Coffee cart",
      body: "Three customized drinks captured with modifiers preserved.",
      reviewMode: "cart",
      stableSheetKey: "foodtrio-coffee",
      focusTargetId: "foodtrio-coffee-iced-vanilla-latte",
      nextQuery: "__checkout_foodtrio_coffee",
      separateSheetNextMove: true,
    });
  }

  if (foodTrioQueryIsFastFood(text)) {
    return orderResult(foodTrioFastFoodOrder(), {
      title: "Cluck & Fry group order",
      body: "Messy group order parsed into ready items, missing choices, optional extras, and one unmatched phrase.",
      reviewMode: "cart",
      stableSheetKey: "foodtrio-fast-food",
      focusTargetId: "foodtrio-fast-original-sandwich-meal",
      nextQuery: "__checkout_foodtrio_fast_food",
      separateSheetNextMove: true,
    });
  }

  if (foodTrioQueryIsCasualDining(text)) {
    // FoodTrio desktop selection-state fix: start casual dining with one red tile
    // and one yellow tile so the demo can show the same resolution choreography as mobile.
    return orderResult(foodTrioCasualDiningOrder(false), {
      title: "Tablehouse Grill order",
      body: "Courses, sides, and dessert are organized into a checkout-ready cart.",
      reviewMode: "cart",
      stableSheetKey: "foodtrio-casual-dining",
      focusTargetId: "foodtrio-casual-herb-salmon",
      // FOODTRIO_CASUAL_MADEIRA_GREEN_EDITABLE:
      // Promote Madeira to green from the start while keeping its side choices editable.
      promoteReadyLineItemId: "casual-madeira",
      nextQuery: "__checkout_foodtrio_casual",
      separateSheetNextMove: true,
    });
  }

  if (
    text.includes("hedge fund") ||
    text.includes("copilot agents") ||
    text.includes("copilots") ||
    text.includes("dora")
  ) {
    return {
      title: "Showing: Hedge Fund industry path",
      body:
        "Yes — this hedge-fund path covers both core IT support needs and AI/copilot-related modernization. In this context, that typically means:\n\n- Secure trading and collaboration infrastructure\n- Cyber/compliance operating model support\n- AI/data visibility and workflow enhancement, including governed copilot-style capabilities\n\nFor a hedge fund, the site frames this as a combined approach: stable infrastructure first, then security/compliance, then AI/data and workflow opportunities in a regulated operating model.",
      invitation: { kind: "next", text: "Want to look specifically at the AI & Data lane for Copilot and agent setup?" },
      nextMove: { type: "ask_deeper", label: "Show Copilot use cases", query: "__copilot_use_cases" },
      canFollowUp: true,
      mode: "speed_info",
      raw: speedMeta({ stableSheetKey: "hedge-fund-path", keepSheetOpenNextMove: true }),
    };
  }

  if (
    text === "__copilot_use_cases" ||
    text.includes("that doesn't say") ||
    text.includes("that doesnt say") ||
    text.includes("what you actually do")
  ) {
    return {
      title: "What we would actually do",
      body:
        "For a hedge fund, the practical Copilot/agent work would usually look like this:\n\n- **Readiness review:** confirm Microsoft 365 permissions, data exposure, identity controls, and security boundaries before anyone turns agents loose.\n- **Use-case selection:** pick a few high-value workflows — investment committee prep, policy lookup, vendor-risk intake, ticket triage, or research summarization.\n- **Agent design:** define what each agent can answer, what systems it can touch, and when it must escalate for review.\n- **Pilot support:** build a small controlled rollout, train the first users, measure adoption, and tighten governance before expanding.",
      invitation: { kind: "case_studies", text: "Show relevant case studies" },
      nextMove: { type: "ask_deeper", label: "Show relevant case studies", query: "__case_studies" },
      canFollowUp: true,
      mode: "speed_info",
      raw: speedMeta({ stableSheetKey: "copilot-use-cases", separateSheetNextMove: true, thinkingOnNextMove: true, nextMoveLoadingMessage: "Choosing the right tool..." }),
    };
  }

  if (text === "__case_studies") {
    return {
      title: "Relevant case studies",
      body:
        "- **Hedge-fund operations assistant:** mapped analyst and operations questions to approved knowledge sources, then routed sensitive requests to human review.\n- **Compliance evidence helper:** organized policy, vendor-risk, and incident-response materials so leaders could ask plain-English questions before audits and tabletop reviews.\n- **Copilot adoption sprint:** coached a regulated firm through safe rollout patterns, permission cleanup, user training, and a short list of practical first agents.",
      invitation: { kind: "handoff", text: "Talk to someone about Copilot support" },
      nextMove: { type: "handoff", label: "Talk to someone about Copilot support", query: "nice, can I talk to someone?" },
      canFollowUp: true,
      mode: "speed_case_studies",
      raw: speedMeta({ stableSheetKey: "case-studies" }),
    };
  }

  if (text.includes("dbl") || text.includes("chzbrger") || text.includes("friez")) {
    return orderResult(readyCarryoutOrder("messy"), {
      title: "Review order",
      nextQuery: "__checkout_messy",
      separateSheetNextMove: true,
    });
  }

  if (text === "__checkout_messy") {
    return orderResult(lockedCarryoutOrder("messy"), {
      title: "Order locked for handoff",
      reviewMode: "cart",
      stableSheetKey: "checkout-messy",
      commerceAction: "carryout_checkout_handoff",
    });
  }

  if (text === "__checkout_qualified") {
    return orderResult(lockedCheeseburgerFriesShakeOrder(), {
      title: "Order locked for handoff",
      reviewMode: "cart",
      stableSheetKey: "checkout-qualified",
      commerceAction: "carryout_checkout_handoff",
    });
  }

  if (text.includes("cheeseburger") && text.includes("fries") && text.includes("milkshake")) {
    return orderResult(pendingCheeseburgerFriesShakeOrder(0), {
      title: "Review order",
      body: "Cart opened with required choices. Pick each missing option to finish checkout.",
      activeIndex: 0,
      reviewMode: "cart",
      nextQuery: "__qualifier_1",
      keepSheetOpenNextMove: true,
    });
  }

  if (text.includes("optional extras") || text.includes("show burger options")) {
    return orderResult(optionalCheeseburgerOrder("plain"), {
      title: "Review order",
      body: "Cheeseburger is ready. Optional extras are available, but checkout is not blocked.",
      reviewMode: "cart",
      nextQuery: "__optional_bacon",
      keepSheetOpenNextMove: true,
    });
  }

  if (text === "__optional_bacon") {
    return orderResult(optionalCheeseburgerOrder("bacon"), {
      title: "Review order",
      body: "Bacon added. The cart is still ready for checkout.",
      reviewMode: "cart",
      nextQuery: "__checkout_optional",
      separateSheetNextMove: true,
    });
  }

  if (text === "__checkout_optional") {
    return orderResult(lockedOptionalCheeseburgerOrder(), {
      title: "Order locked for handoff",
      reviewMode: "cart",
      stableSheetKey: "checkout-optional",
      commerceAction: "carryout_checkout_handoff",
    });
  }

  if (text.includes("med rings") || text.includes("medium onion rings")) {
    return orderResult(retriedMediumOnionRingsOrder(), {
      title: "Review order",
      body: "Medium onion rings added. The gray item was replaced.",
      reviewMode: "cart",
      stableSheetKey: "retry-onion-rings",
      promoteReadyLineItemId: "medium-onion-rings",
      focusTargetId: "side-onion-rings",
    });
  }

  if (text.includes("lava tacos") || text.includes("not on the menu")) {
    return orderResult(cannotMatchTacoOrder(), {
      title: "Review order",
      body: "Matched items ready. The gray row(s) held out.",
      reviewMode: "cart",
      stableSheetKey: "cannot-match-tacos",
      nextMoveLoadingMessage: "Checking the BurgerRush menu...",
    });
  }

  if (text.includes("burger combo")) {
    return orderResult(pendingCarryoutOrder(0), {
      title: "Choose required options",
      body: "Burger combo meal needs required selections before checkout.",
      activeIndex: 0,
      reviewMode: "review",
      nextQuery: "__qualifier_1",
      keepSheetOpenNextMove: true,
    });
  }

  if (text === "__qualifier_1") {
    return orderResult(pendingCheeseburgerFriesShakeOrder(1), {
      title: "Review order",
      body: "Cheeseburger setup captured. Fries still needs a required choice.",
      activeIndex: 1,
      reviewMode: "cart",
      nextQuery: "__qualifier_2",
      keepSheetOpenNextMove: true,
      promoteReadyLineItemId: "cheeseburger",
    });
  }

  if (text === "__qualifier_2") {
    return orderResult(pendingCheeseburgerFriesShakeOrder(2), {
      title: "Review order",
      body: "Fries size captured. Milkshake flavor is the last required choice.",
      activeIndex: 2,
      reviewMode: "cart",
      nextQuery: "__qualifier_3",
      keepSheetOpenNextMove: true,
      promoteReadyLineItemId: "fries-size",
    });
  }

  if (text === "__qualifier_3") {
    return orderResult(readyCheeseburgerFriesShakeOrder(), {
      title: "Review order",
      nextQuery: "__checkout_qualified",
      separateSheetNextMove: true,
      promoteReadyLineItemId: "milkshake",
    });
  }

  if (text === "__booking_step_1" || text.includes("nice room") || text.includes("view and breakfast")) {
    return {
      title: "Recommendation 1 of 3",
      body:
        "$239/night. A quieter garden-facing option with a resort feel and lower price. It is a value fit, but the view is softer than the Ocean View Suite.",
      nextMove: { type: "compare_options", label: "Next stop", query: "__booking_step_2" },
      canFollowUp: true,
      mode: "speed_booking_reco",
      raw: speedMeta({ keepSheetOpenNextMove: true, stableSheetKey: "booking-recommendations" }),
    };
  }

  if (text === "__booking_step_2") {
    return {
      title: "Recommendation 2 of 3",
      body:
        "$379/night. Best fit for a strong view without jumping to the villa tier. Breakfast can be attached with the Breakfast Flex Plan.",
      nextMove: { type: "compare_options", label: "Next stop", query: "__booking_step_3" },
      canFollowUp: true,
      mode: "speed_booking_reco",
      raw: speedMeta({ keepSheetOpenNextMove: true, stableSheetKey: "booking-recommendations" }),
    };
  }

  if (text === "__booking_step_3") {
    return {
      title: "Recommendation 3 of 3",
      body:
        "$549/night. The premium view-and-space option. It is stronger than needed for this request, so the Ocean View Suite remains the practical recommendation.",
      canFollowUp: true,
      mode: "speed_booking_reco",
      raw: speedMeta({ stableSheetKey: "booking-recommendations" }),
    };
  }

  if (text.includes("breakfast")) {
    return {
      title: "Breakfast Flex Plan",
      body: "Daily breakfast credit across the lobby café, buffet, and grab-and-go market. +$32/night.",
      invitation: { kind: "book", text: "Book this" },
      nextMove: { type: "handoff", label: "Book this", query: "__booking_confirm" },
      canFollowUp: true,
      mode: "speed_package",
      raw: speedMeta({ stableSheetKey: "booking-package" }),
    };
  }

  if (text === "__booking_confirm") {
    return {
      title: "Booking summary ready",
      canFollowUp: false,
      mode: "speed_booking_confirm",
      raw: {
        ...speedMeta({ stableSheetKey: "booking-confirm" }),
        bookingHandoff: bookingHandoff("ocean"),
      },
    };
  }

  if (text.includes("family room")) {
    return {
      title: "Select your stay dates",
      body: "I need stay dates before I can price and rank family-room options. Choose check-in and check-out dates to continue.",
      canFollowUp: false,
      answerMode: "tourbar_collect_dates",
      mode: "tourbar_collect_dates",
      action: "tourbar_collect_dates",
      label: "Dates required",
      raw: {
        mode: "tourbar_collect_dates",
        action: "tourbar_collect_dates",
        requiredField: "dates",
        pendingQuery: "",
      },
    };
  }

  if (text === "__booking_after_context" || text.includes("family recommendation")) {
    return {
      title: "Family Double Room recommended",
      body: "Family Double Room · $249/night.\nFamily Comfort Bundle · +$55/stay.\nStay context: Jun 12–15, 2026 · 2 adults / 2 children.",
      invitation: { kind: "book", text: "Book this family stay" },
      nextMove: { type: "handoff", label: "Book this family stay", query: "__family_booking_confirm" },
      canFollowUp: true,
      mode: "speed_family_reco",
      raw: speedMeta({ stableSheetKey: "family-recommendation" }),
    };
  }

  if (text === "__family_booking_confirm") {
    return {
      title: "Family booking summary ready",
      canFollowUp: false,
      mode: "speed_booking_confirm",
      raw: {
        ...speedMeta({ stableSheetKey: "family-confirm" }),
        bookingHandoff: bookingHandoff("family"),
      },
    };
  }

  if (text.includes("after hours") || text.includes("lead capture") || text.includes("offline handoff")) {
    return {
      title: "After-hours request capture",
      body: "When the consultant desk is offline, SmartBar switches from live chat to a reusable lead-capture sheet.",
      canFollowUp: false,
      mode: "speed_after_hours",
      raw: speedMeta({ stableSheetKey: "finale-after-hours" }),
    };
  }

  if (text.includes("action choices") || text.includes("tiles")) {
    return {
      title: "Choose next action",
      canFollowUp: false,
      mode: "speed_tiles",
      raw: speedMeta({ stableSheetKey: "finale-tiles" }),
    };
  }

  if (text.includes("pending cart")) {
    return orderResult(pendingCarryoutOrder(0), {
      title: "Review order",
      reviewMode: "cart",
      stableSheetKey: "finale-pending-cart",
    });
  }

  if (text.includes("final cart") || text.includes("cart")) {
    return orderResult(readyCarryoutOrder("finale"), {
      title: "Review order",
      reviewMode: "cart",
      stableSheetKey: "finale-final-cart",
    });
  }

  if (text.includes("summary")) {
    return {
      title: "Booking summary ready",
      canFollowUp: false,
      mode: "speed_booking_confirm",
      raw: {
        ...speedMeta({ stableSheetKey: "finale-booking-summary" }),
        bookingHandoff: bookingHandoff("ocean"),
      },
    };
  }

  return {
    title: "SmartBar in one line",
    body:
      "SmartBar turns a plain visitor question into the next useful action.\nIt can answer, guide, qualify, compare, collect, and hand off without making the user hunt through the site.\nOn content-heavy sites, it behaves like a navigator.\nOn ordering or booking sites, it behaves like a completion layer.\nThe CTA is simple: ask for what you want, then let SmartBar open the right next step.",
    invitation: { kind: "next", text: "Show me what it can do" },
    nextMove: { type: "ask_deeper", label: "Show me what it can do", query: "show action choices" },
    canFollowUp: true,
    mode: "speed_info",
    raw: speedMeta({ stableSheetKey: "finale-natural-language" }),
  };
}

const SPEED_BOOKING_RECO_STEPS: TourBarBookingNavigationState["steps"] = [
  {
    pageId: "rooms",
    targetId: "room-garden-terrace",
    targetText: "Garden Terrace King",
  },
  {
    pageId: "rooms",
    targetId: "room-ocean-view-suite",
    targetText: "Ocean View Suite",
  },
  {
    pageId: "rooms",
    targetId: "room-coastal-villa",
    targetText: "Coastal Villa Suite",
  },
];

function speedBookingRecoIndex(result: TourBarShellResult) {
  const title = result.title || "";
  if (title.includes("2 of 3")) return 1;
  if (title.includes("3 of 3")) return 2;
  return 0;
}

function speedBookingRecoNavigationState(result: TourBarShellResult): TourBarBookingNavigationState {
  return {
    steps: SPEED_BOOKING_RECO_STEPS,
    activeIndex: speedBookingRecoIndex(result),
  };
}

function speedDemoOrderTarget(result: TourBarShellResult) {
  const raw = (result.raw || {}) as GuideAiCarryoutResponse;
  const order = raw.carryoutOrder || raw.visibleContext?.carryoutOrder || null;
  if (!order) return null;

  const explicitTarget = (raw as GuideAiCarryoutResponse & { __speedDemo?: { focusTargetId?: string } }).__speedDemo?.focusTargetId;
  if (explicitTarget) return explicitTarget;

  const currentTarget = order.currentStep?.targetId;
  if (currentTarget) return currentTarget;

  const firstPending = (order.items || order.pendingItems || []).find((line) => {
    const status = String(line.status || "").toLowerCase();
    return status.includes("pending") || status.includes("need") || Boolean(line.missingQualifiers?.length);
  });

  return firstPending?.targetId || null;
}

function speedDemoResultTarget(result: TourBarShellResult) {
  const mode = result.mode || "";

  if (mode === "speed_order") return speedDemoOrderTarget(result);
  if (mode === "speed_booking_reco") return SPEED_BOOKING_RECO_STEPS[speedBookingRecoIndex(result)]?.targetId || null;
  if (mode === "speed_package") return "package-breakfast-flex";
  if (mode === "speed_family_reco") return "room-family-double";
  if (mode === "speed_info" || mode === "speed_case_studies") return "hedgefund-copilot";

  return null;
}

function renderMobileSpeedControls(result: TourBarShellResult, actions: TourBarShellActions) {
  const mode = result.mode || "";

  if (mode === "speed_booking_reco") {
    const activeIndex = speedBookingRecoIndex(result);
    const backQuery = activeIndex === 2 ? "__booking_step_2" : activeIndex === 1 ? "__booking_step_1" : "";
    const nextQuery = activeIndex === 0 ? "__booking_step_2" : activeIndex === 1 ? "__booking_step_3" : "";

    return (
      <div className="grid grid-cols-[1fr_auto_1fr] items-center gap-3">
        <button
          type="button"
          data-tourbar-booking-nav="back"
          data-tourbar-booking-nav-state={!backQuery ? "disabled" : "enabled"}
          onClick={() => backQuery && actions.submitFollowUp(backQuery)}
          disabled={!backQuery}
          aria-label="Previous recommendation"
          className="inline-flex h-8 w-8 items-center justify-center justify-self-start rounded-full border border-white/15 bg-slate-950 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.16),0_8px_18px_rgba(0,0,0,0.34)] transition hover:-translate-y-0.5 hover:border-white/25 hover:bg-slate-900 disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:translate-y-0"
        >
          <ChevronLeft className="h-4 w-4" />
        </button>
        <div className="min-w-10 text-center text-[11px] font-semibold text-white/45">
          {activeIndex + 1}/3
        </div>
        <button
          type="button"
          data-tourbar-booking-nav="next"
          data-tourbar-booking-nav-state={!nextQuery ? "disabled" : "enabled"}
          onClick={() => nextQuery && actions.submitFollowUp(nextQuery)}
          disabled={!nextQuery}
          aria-label="Next recommendation"
          className="inline-flex h-8 w-8 items-center justify-center justify-self-end rounded-full border border-white/15 bg-slate-950 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.16),0_8px_18px_rgba(0,0,0,0.34)] transition hover:-translate-y-0.5 hover:border-white/25 hover:bg-slate-900 disabled:cursor-not-allowed disabled:opacity-30 disabled:hover:translate-y-0"
        >
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    );
  }

  if (mode === "speed_order") {
    // OrderReview owns food cart / qualifier controls. Suppress the generic
    // mobile next-move link so internal qualifier steps do not add/remove an
    // extra CTA row and jerk the sheet height between items.
    return null;
  }

  if (result.nextMove?.query) {
    return (
      <div className="flex w-full justify-center">
        <button
          type="button"
          data-tourbar-nextmove-button="true"
          data-tourbar-nextmove-label={result.nextMove.label || result.invitation?.text || "Next"}
          data-tourbar-nextmove-query={result.nextMove.query || ""}
          data-tourbar-nextmove-invitation={result.invitation?.text || ""}
          onClick={() => actions.submitFollowUp(result.nextMove?.query || result.nextMove?.label || "")}
          className="inline-flex items-center justify-center px-1 py-1 text-xs font-black text-sky-300 underline underline-offset-4 transition hover:text-sky-100"
        >
          {result.nextMove.label || result.invitation?.text || "Next"}
        </button>
      </div>
    );
  }

  return null;
}


function speedDemoCloneOrder(order: CarryoutOrder | null): CarryoutOrder | null {
  if (!order) return null;
  return JSON.parse(JSON.stringify(order)) as CarryoutOrder;
}

function speedDemoOptionRawId(option: CarryoutQualifierOption) {
  return String(option.value || option.label || "").trim();
}

function speedDemoOptionKey(option: CarryoutQualifierOption) {
  return speedDemoOptionRawId(option).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "option";
}

function speedDemoLineKeys(line: CarryoutLine) {
  return [line.lineItemId, line.id].filter((value): value is string => Boolean(value));
}

function speedDemoLineMatchesReviewItem(line: CarryoutLine, item: ReviewItem) {
  const targetKeys = speedDemoLineKeys(item.line);
  const lineKeys = speedDemoLineKeys(line);
  return Boolean(
    lineKeys.some((key) => targetKeys.includes(key)) ||
      (line.targetId && item.line.targetId && line.targetId === item.line.targetId) ||
      (line.title && item.line.title && line.title === item.line.title),
  );
}

function speedDemoReviewItemResolvedKeys(item: ReviewItem) {
  return [item.key, item.line.lineItemId, item.line.id, item.line.targetId].filter((value): value is string => Boolean(value));
}

function speedDemoMergeResolvedKeyList(current: string, nextKeys: Array<string | undefined | null>) {
  const keys = new Set(
    String(current || "")
      .split("|")
      .map((value) => value.trim())
      .filter(Boolean),
  );

  nextKeys
    .map((value) => String(value || "").trim())
    .filter(Boolean)
    .forEach((value) => keys.add(value));

  return Array.from(keys).join("|");
}

function speedDemoResolvedKeySet(keyList: string) {
  return new Set(
    String(keyList || "")
      .split("|")
      .map((value) => value.trim())
      .filter(Boolean),
  );
}

function speedDemoLineMatchesResolvedKeySet(line: CarryoutLine, resolvedKeys: Set<string>) {
  if (!resolvedKeys.size) return false;
  return [line.lineItemId, line.id, line.targetId]
    .map((value) => String(value || "").trim())
    .filter(Boolean)
    .some((value) => resolvedKeys.has(value));
}

function speedDemoBuildFoodTrioSnapshotOrder(order: CarryoutOrder | null, resolvedKeyList: string) {
  const nextOrder = speedDemoCloneOrder(order);
  if (!nextOrder) return null;

  const resolvedKeys = speedDemoResolvedKeySet(resolvedKeyList);
  if (!resolvedKeys.size) return nextOrder;

  const lines = Array.isArray(nextOrder.items)
    ? nextOrder.items
    : [...(nextOrder.completeItems || []), ...(nextOrder.pendingItems || [])];

  nextOrder.items = lines.map((line) => {
    if (!speedDemoLineMatchesResolvedKeySet(line, resolvedKeys)) return line;

    return {
      ...line,
      status: "ready",
      missingQualifiers: [],
      priceLabel: line.priceLabel || SPEED_DEMO_FOODTRIO_PRICE_BY_LINE_ID[line.lineItemId || line.id || ""],
      qualifierGroups: (line.qualifierGroups || []).map((group) => ({
        ...group,
        missing: false,
      })),
    };
  });

  // FoodTrio desktop hard-snapshot reset:
  // the demo advances explicit visual snapshots. Once a red/yellow/gray tile is
  // handled, the rendered cart is rebuilt from the snapshot key list instead of
  // letting later fixture updates resurrect earlier yellow/red states.
  return speedDemoNormalizeFoodTrioOrder(nextOrder);
}


function speedDemoGroupMatches(a: CarryoutQualifierGroup, b: CarryoutQualifierGroup) {
  return Boolean(
    (a.qualifierId && b.qualifierId && a.qualifierId === b.qualifierId) ||
      (a.label && b.label && a.label === b.label) ||
      (a.targetId && b.targetId && a.targetId === b.targetId),
  );
}

function speedDemoSelectedLabel(option: CarryoutQualifierOption) {
  return String(option.label || option.value || "").trim();
}

const SPEED_DEMO_FOODTRIO_PRICE_BY_LINE_ID: Record<string, string> = {
  "fast-spicy-meal": "$10.99",
  "fast-mild-meal": "$10.49",
  "fast-kids-nuggets": "$5.99",
  "foodtrio-retry-crispy-chicken-wrap": "$8.99",
};

function speedDemoLineStillPending(line: CarryoutLine) {
  const status = String(line.status || "").toLowerCase();
  return Boolean(
    status.includes("pending") ||
      status.includes("need") ||
      line.missingQualifiers?.length ||
      line.qualifierGroups?.some((group) => Boolean(group.required && group.missing)),
  );
}

function speedDemoMoneyNumber(priceLabel?: string | null) {
  const value = Number(String(priceLabel || "").replace(/[^0-9.]+/g, ""));
  return Number.isFinite(value) ? value : 0;
}

function speedDemoNormalizeFoodTrioOrder(order: CarryoutOrder | null): CarryoutOrder | null {
  if (!order) return null;

  const lines = Array.isArray(order.items)
    ? order.items
    : [...(order.completeItems || []), ...(order.pendingItems || [])];
  const pendingItems = lines.filter(speedDemoLineStillPending);
  const completeItems = lines.filter((line) => !speedDemoLineStillPending(line));
  const cannotMatchItems = order.cannotMatchItems || [];
  const subtotal = completeItems.reduce((total, line) => total + speedDemoMoneyNumber(line.priceLabel), 0);
  const estimatedTax = subtotal > 0 ? Math.round(subtotal * 0.08 * 100) / 100 : null;
  const estimatedTotal = subtotal > 0 && estimatedTax !== null ? Math.round((subtotal + estimatedTax) * 100) / 100 : null;

  return {
    ...order,
    items: lines,
    completeItems,
    pendingItems,
    status: pendingItems.length ? (cannotMatchItems.length ? "partial_match" : "needs_qualifier") : cannotMatchItems.length ? "partial_match" : "ready_cart",
    nextAction: pendingItems.length ? "choose_qualifier" : "show_cart",
    currentStep: pendingItems[0]
      ? {
          type: "qualifier",
          itemId: pendingItems[0].id || pendingItems[0].lineItemId,
          targetId: pendingItems[0].targetId,
          qualifierId: pendingItems[0].qualifierGroups?.[0]?.qualifierId,
          question: pendingItems[0].qualifierGroups?.[0]?.label,
        }
      : undefined,
    totals: {
      ...(order.totals || {}),
      status: pendingItems.length || cannotMatchItems.length ? "partial" : "ready",
      subtotal: subtotal || order.totals?.subtotal || null,
      estimatedTax: pendingItems.length ? null : estimatedTax,
      estimatedTotal: pendingItems.length ? null : estimatedTotal,
      currency: order.totals?.currency || "USD",
    },
  };
}

function speedDemoApplyLocalOptionSelection(
  currentOrder: CarryoutOrder | null,
  item: ReviewItem,
  group: CarryoutQualifierGroup,
  option: CarryoutQualifierOption,
) {
  const nextOrder = speedDemoCloneOrder(currentOrder);
  if (!nextOrder) return null;

  const lines = Array.isArray(nextOrder.items)
    ? nextOrder.items
    : [...(nextOrder.completeItems || []), ...(nextOrder.pendingItems || [])];
  const targetLine = lines.find((line) => speedDemoLineMatchesReviewItem(line, item));
  if (!targetLine) return nextOrder;

  const selectedLabel = speedDemoSelectedLabel(option);
  const selectedValue = option.value || option.label || "";
  const isRequired = Boolean(group.required || group.missing || item.pending);
  const allowsMulti = String(group.selectionMode || "").toLowerCase() === "multi" || String(group.kind || "").toLowerCase() === "modifier";
  const optionKey = speedDemoOptionKey(option);
  let foundGroup = false;

  let selectedWasAlreadyOnForTargetGroup = false;

  targetLine.qualifierGroups = (targetLine.qualifierGroups || []).map((candidate) => {
    if (!speedDemoGroupMatches(candidate, group)) return candidate;
    foundGroup = true;

    const currentOptions = candidate.options || group.options || [];
    const selectedWasAlreadyOn = currentOptions.some((candidateOption) => {
      const candidateSelected = Boolean(candidateOption.selected || candidateOption.state === "selected");
      return candidateSelected && speedDemoOptionKey(candidateOption) === optionKey;
    }) || (targetLine.knownSelections || []).some((selection) => String(selection || "").trim().toLowerCase() === String(selectedLabel || "").trim().toLowerCase() || String(selection || "").trim().toLowerCase() === String(selectedValue || "").trim().toLowerCase());
    selectedWasAlreadyOnForTargetGroup = selectedWasAlreadyOn;

    const nextOptions = currentOptions.map((candidateOption) => {
      const selected = speedDemoOptionKey(candidateOption) === optionKey
        ? allowsMulti && !isRequired
          ? !selectedWasAlreadyOn
          : true
        : allowsMulti && !isRequired
          ? Boolean(candidateOption.selected || candidateOption.state === "selected")
          : false;

      return {
        ...candidateOption,
        selected,
        state: selected ? "selected" : "available",
      };
    });

    return {
      ...candidate,
      missing: isRequired ? false : candidate.missing,
      selectedValue: isRequired ? selectedValue : candidate.selectedValue,
      selectedLabel: isRequired ? selectedLabel : candidate.selectedLabel,
      options: nextOptions,
    };
  });

  if (!foundGroup) {
    targetLine.qualifierGroups = [
      ...(targetLine.qualifierGroups || []),
      {
        ...group,
        missing: false,
        selectedValue,
        selectedLabel,
        options: (group.options || []).map((candidateOption) => {
          const selected = speedDemoOptionKey(candidateOption) === optionKey;
          return { ...candidateOption, selected, state: selected ? "selected" : "available" };
        }),
      },
    ];
  }

  const knownSelections = new Set((targetLine.knownSelections || []).filter(Boolean));
  const targetLineIdForSelection = String(targetLine.lineItemId || targetLine.id || "");
  const casualMadeiraSideLabels = ["Asparagus", "Rice pilaf", "Side salad", "Mashed potatoes"];
  const selectedLooksLikeCasualMadeiraSide = casualMadeiraSideLabels.some(
    (label) => String(label).trim().toLowerCase() === String(selectedLabel || "").trim().toLowerCase(),
  );

  if (targetLineIdForSelection === "casual-madeira" && !isRequired && selectedLabel && selectedLooksLikeCasualMadeiraSide) {
    // FOODTRIO_CASUAL_CLEAN_BEAT_STORY:
    // Madeira is a green ready tile being changed. Side salad replaces mashed
    // potatoes instead of being treated like an added extra.
    const nextKnownSelections = Array.from(knownSelections).filter(
      (selection) =>
        !casualMadeiraSideLabels.some(
          (label) => String(label).trim().toLowerCase() === String(selection || "").trim().toLowerCase(),
        ),
    );
    knownSelections.clear();
    nextKnownSelections.forEach((selection) => knownSelections.add(selection));
    knownSelections.add(selectedLabel);
  } else if (allowsMulti && !isRequired && selectedLabel) {
    if (selectedWasAlreadyOnForTargetGroup) {
      knownSelections.delete(selectedLabel);
      if (selectedValue) knownSelections.delete(selectedValue);
    } else {
      knownSelections.add(selectedLabel);
    }
  } else if (selectedLabel) {
    knownSelections.add(selectedLabel);
  }
  targetLine.knownSelections = Array.from(knownSelections);

  if (isRequired) {
    targetLine.status = "ready";
    targetLine.missingQualifiers = [];
    targetLine.priceLabel = targetLine.priceLabel || SPEED_DEMO_FOODTRIO_PRICE_BY_LINE_ID[targetLine.lineItemId || targetLine.id || ""];
  }

  nextOrder.items = lines;
  return speedDemoNormalizeFoodTrioOrder(nextOrder);
}

function speedDemoReplaceCannotMatchItem(currentOrder: CarryoutOrder | null, retryIndex: number, retryValue: string) {
  const nextOrder = speedDemoCloneOrder(currentOrder);
  if (!nextOrder) return null;

  const cleanValue = retryValue.trim() || "Crispy chicken wrap";
  const retryLine: CarryoutLine = {
    lineItemId: "foodtrio-retry-crispy-chicken-wrap",
    id: "foodtrio-retry-crispy-chicken-wrap",
    targetId: "foodtrio-fast-crispy-wrap",
    title: cleanValue,
    quantity: 1,
    priceLabel: SPEED_DEMO_FOODTRIO_PRICE_BY_LINE_ID["foodtrio-retry-crispy-chicken-wrap"],
    status: "ready",
    knownSelections: ["Matched from retry"],
    qualifierGroups: [],
  };

  const lines = Array.isArray(nextOrder.items)
    ? [...nextOrder.items]
    : [...(nextOrder.completeItems || []), ...(nextOrder.pendingItems || [])];

  nextOrder.items = [retryLine, ...lines];
  nextOrder.cannotMatchItems = (nextOrder.cannotMatchItems || []).filter((_, index) => index !== retryIndex);
  return speedDemoNormalizeFoodTrioOrder(nextOrder);
}

type SmartBarSpeedOrderReviewProps = {
  result: TourBarShellResult;
  actions: TourBarShellActions;
  orderReviewAppearance?: "light";
  blueGlassOrderReview?: boolean;
  onNavigateToFocus?: (target: TourBarOrderingFocusTarget) => void;
};

function SmartBarSpeedOrderReview({
  result,
  actions,
  orderReviewAppearance = "light",
  blueGlassOrderReview = false,
  onNavigateToFocus,
}: SmartBarSpeedOrderReviewProps) {
  const raw = (result.raw || {}) as GuideAiCarryoutResponse & { __speedDemo?: { activeIndex?: number; reviewMode?: ReviewMode; stableSheetKey?: string } };
  const fixtureOrder = raw.carryoutOrder || raw.visibleContext?.carryoutOrder || null;
  // FoodTrio desktop rebuild: blue/glass demo state resets by fixture/order key only.
  // Do not include item/cannot-match mutations in the reset key, or resolving gray
  // rows remounts the review and wipes already-resolved red/yellow snapshots.
  const baseResetKey = raw.__speedDemo?.stableSheetKey || result.title || "order";
  const fixtureResetKey = `${baseResetKey}-${(fixtureOrder?.items || []).map((line) => line.lineItemId || line.id || line.title).join("|")}-${(fixtureOrder?.cannotMatchItems || []).map((item) => item.text || item.label || item.title || item.item).join("|")}`;
  const resetKey = blueGlassOrderReview ? baseResetKey : fixtureResetKey;
  const [localOrder, setLocalOrder] = useState<CarryoutOrder | null>(() => speedDemoCloneOrder(fixtureOrder));
  const [speedDemoResolvedLineItemIds, setSpeedDemoResolvedLineItemIds] = useState("");

  useEffect(() => {
    setLocalOrder(speedDemoCloneOrder(fixtureOrder));
    setSpeedDemoResolvedLineItemIds("");
  }, [resetKey]);

  const snapshotOrder = useMemo(
    () => (blueGlassOrderReview
      ? speedDemoBuildFoodTrioSnapshotOrder(localOrder || fixtureOrder, speedDemoResolvedLineItemIds)
      : localOrder || fixtureOrder),
    [blueGlassOrderReview, fixtureOrder, localOrder, speedDemoResolvedLineItemIds],
  );

  return (
    <OrderReview
      key={resetKey}
      appearance={orderReviewAppearance}
      blueGlassSurface={blueGlassOrderReview}
      speedDemoResolvedLineItemIds={speedDemoResolvedLineItemIds}
      result={result}
      actions={actions}
      carryoutOrder={snapshotOrder}
      activeIndex={raw.__speedDemo?.activeIndex || 0}
      reviewMode={raw.__speedDemo?.reviewMode || "cart"}
      onActiveIndexChange={() => undefined}
      onReviewModeChange={() => undefined}
      onLocalOptionSelect={(item, group, option) => {
        const nextOrder = speedDemoApplyLocalOptionSelection(localOrder || fixtureOrder, item, group, option);
        setLocalOrder(nextOrder);
        // FoodTrio desktop snapshot stabilization:
        // the visible demo is cinematic, not an emergent cart-state exercise.
        // Once a tile has been handled by the script, keep that tile promoted
        // for the current order so later actions, especially gray retry, cannot
        // rebuild the original fixture and turn completed yellow tiles back yellow.
        if (blueGlassOrderReview) {
          setSpeedDemoResolvedLineItemIds((current) =>
            speedDemoMergeResolvedKeyList(current, speedDemoReviewItemResolvedKeys(item)),
          );
        }
        return nextOrder;
      }}
      onSilentReprice={(nextOrder) => {
        if (nextOrder) setLocalOrder(speedDemoNormalizeFoodTrioOrder(speedDemoCloneOrder(nextOrder)));
      }}
      onRemoveItem={() => undefined}
      onRetryItemReplace={(retryIndex, retryValue) => {
        const nextOrder = speedDemoReplaceCannotMatchItem(localOrder || fixtureOrder, retryIndex, retryValue);
        setLocalOrder(nextOrder);
        if (blueGlassOrderReview) {
          setSpeedDemoResolvedLineItemIds((current) =>
            speedDemoMergeResolvedKeyList(current, ["foodtrio-retry-crispy-chicken-wrap"]),
          );
        }
      }}
      // FOODTRIO_DESKTOP_ITEM_TAP_SPOTLIGHT_FIX:
      // The desktop speed-demo wrapper renders OrderReview directly, so it must
      // forward item tile focus requests. Without this, red/yellow/gray tile taps
      // open panels but never scroll/spotlight the matching menu card.
      onNavigateToFocus={onNavigateToFocus}
      notOnMenuLabel="Not on the demo menu"
    />
  );
}

function renderSpeedExtras(
  result: TourBarShellResult,
  actions: TourBarShellActions,
  orderReviewAppearance: "light" = "light",
  blueGlassOrderReview = false,
  onNavigateToFocus?: (target: TourBarOrderingFocusTarget) => void,
) {
  const mode = result.mode || "";

  if (mode === "speed_order") {
    return (
      <SmartBarSpeedOrderReview
        result={result}
        actions={actions}
        orderReviewAppearance={orderReviewAppearance}
        blueGlassOrderReview={blueGlassOrderReview}
        onNavigateToFocus={onNavigateToFocus}
      />
    );
  }

  if (mode === "speed_needs_context") {
    return (
      <div className="grid grid-cols-2 gap-2">
        <button type="button" onClick={() => actions.openBookingContextSheet("dates")} className="rounded-2xl border border-slate-200 bg-white p-3 text-left shadow-sm transition hover:bg-slate-50">
          <CalendarDays className="h-4 w-4 text-slate-500" />
          <div className="mt-2 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Dates</div>
          <div className="text-sm font-semibold text-slate-950">Select dates</div>
        </button>
        <button type="button" onClick={() => actions.openBookingContextSheet("guests")} className="rounded-2xl border border-slate-200 bg-white p-3 text-left shadow-sm transition hover:bg-slate-50">
          <Users className="h-4 w-4 text-slate-500" />
          <div className="mt-2 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400">Guests</div>
          <div className="text-sm font-semibold text-slate-950">Add guests</div>
        </button>
      </div>
    );
  }

  if (mode === "speed_booking_reco") {
    if (speedDemoIsPhoneViewport()) return null;

    const activeIndex = speedBookingRecoIndex(result);
    const backQuery = activeIndex === 2 ? "__booking_step_2" : activeIndex === 1 ? "__booking_step_1" : "";
    const nextQuery = activeIndex === 0 ? "__booking_step_2" : activeIndex === 1 ? "__booking_step_3" : "";

    return (
      <TourBarNavigationControls
        state={speedBookingRecoNavigationState(result)}
        onBack={backQuery ? () => actions.submitFollowUp(backQuery) : undefined}
        onNext={nextQuery ? () => actions.submitFollowUp(nextQuery) : undefined}
      />
    );
  }

  if (mode === "speed_booking_confirm") {
    const raw = (result.raw || {}) as { bookingHandoff?: TourBarBookingHandoff };
    return (
      <TourBarBookingHandoffSheet
        bookingHandoff={raw.bookingHandoff || null}
        actions={actions}
      />
    );
  }

  if (mode === "speed_after_hours") {
    return (
      <TourBarAfterHoursLeadSheet
        initialEmail="visitor@riverstonecap.com"
        initialNote="I watched the SmartBar demo and want to talk through pricing and rollout options."
        contextSummary="Visitor asked for consultant help after reviewing SmartBar capabilities."
      />
    );
  }

  if (mode === "speed_tiles") {
    return (
      <div className="overflow-hidden rounded-3xl border border-orange-100 bg-gradient-to-br from-orange-50 via-white to-amber-50 shadow-sm ring-1 ring-orange-100/70">
        <div className="relative min-h-[132px] p-4">
          <div className="absolute -right-8 -top-10 h-28 w-28 rounded-full bg-orange-200/45 blur-2xl" />
          <div className="relative flex items-start gap-3">
            <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-3xl bg-white text-3xl shadow-sm ring-1 ring-orange-100">
              🍔
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-[10px] font-black uppercase tracking-[0.18em] text-orange-500">Featured item</div>
              <div className="mt-1 text-lg font-black tracking-tight text-slate-950">Double cheeseburger combo</div>
              <div className="mt-1 text-sm font-semibold text-slate-600">Large fries · Large Diet Coke · No onions</div>
              <div className="mt-3 flex items-center justify-between gap-3">
                <span className="rounded-full bg-slate-950 px-3 py-1 text-xs font-black text-white">$11.99</span>
                <span className="text-xs font-bold text-slate-500">SmartBar can turn a food request into a structured item slide.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return null;
}

function SmartBarDemoFoodOrdersEndScreen() {
  return (
    <main className="relative h-[100svh] min-h-[100svh] overflow-hidden bg-[radial-gradient(circle_at_18%_12%,_rgba(56,189,248,0.22),_transparent_34%),radial-gradient(circle_at_88%_78%,_rgba(59,130,246,0.18),_transparent_32%),linear-gradient(135deg,_#eff8ff_0%,_#dff0ff_48%,_#f8fbff_100%)] text-slate-950">
      <div className="pointer-events-none absolute inset-0 opacity-[0.16] [background-image:linear-gradient(rgba(15,23,42,0.08)_1px,transparent_1px),linear-gradient(90deg,rgba(15,23,42,0.08)_1px,transparent_1px)] [background-size:44px_44px]" />
      <div className="pointer-events-none absolute -right-28 top-16 h-72 w-72 rounded-full bg-sky-300/22 blur-3xl" />
      <div className="pointer-events-none absolute -left-24 bottom-10 h-72 w-72 rounded-full bg-blue-300/20 blur-3xl" />

      <motion.div
        aria-hidden="true"
        initial={{ opacity: 0, scale: 0.92, rotate: -4 }}
        animate={{ opacity: 1, scale: 1, rotate: 0 }}
        transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
        className="pointer-events-none absolute inset-0 z-[4] flex items-center justify-center"
      >
        <Compass className="h-[56svh] max-h-[540px] w-[56svh] max-w-[540px] text-sky-500/12" strokeWidth={1.28} />
      </motion.div>

      <motion.div
        initial={{ y: 24, opacity: 0, scale: 0.985 }}
        animate={{ y: 0, opacity: 1, scale: 1 }}
        transition={{ duration: 0.58, delay: 0.18, ease: [0.22, 1, 0.36, 1] }}
        className="absolute left-6 right-6 top-[38svh] z-[20] rounded-[28px] border border-white/82 bg-white/88 px-5 py-3.5 text-center text-[22px] font-black leading-[1.04] tracking-[-0.05em] text-slate-950 shadow-[0_18px_54px_rgba(15,23,42,0.13)] backdrop-blur-xl"
      >
        Turning words into orders
      </motion.div>

      <motion.div
        initial={{ y: "20svh", opacity: 0, scale: 0.98 }}
        animate={{ y: ["20svh", "0svh", "0svh"], opacity: [0, 1, 1], scale: [0.98, 1, 1] }}
        transition={{ duration: 1.72, delay: 1.0, times: [0, 0.62, 1], ease: [0.22, 1, 0.36, 1] }}
        className="absolute inset-x-0 top-[calc(64svh-58px)] z-[30] flex items-center justify-center"
      >
        <div className="relative flex h-[46px] w-[260px] shrink-0 items-center justify-center overflow-hidden rounded-full border border-white/30 bg-[linear-gradient(180deg,_rgba(20,34,92,0.96)_0%,_rgba(17,29,82,0.98)_52%,_rgba(13,23,68,0.99)_100%)] px-4 text-white shadow-[inset_0_1px_0_rgba(255,255,255,0.26),inset_0_-1px_0_rgba(2,6,23,0.48),0_16px_38px_rgba(2,6,23,0.30),0_5px_14px_rgba(2,6,23,0.18)] backdrop-blur-[18px]">
          <span className="inline-flex h-8 max-w-full items-center justify-center gap-1.5 whitespace-nowrap px-4 text-[18px] font-semibold tracking-[-0.025em] text-white">
            <Compass className="h-[18px] w-[18px] shrink-0 text-white" strokeWidth={2.25} />
            <span>SmartBar</span>
          </span>
        </div>
      </motion.div>
    </main>
  );
}

function SmartBarDemoReplayScreen({ onReplay, mode = "replay" }: { onReplay: () => void; mode?: "replay" | "foodOrdersEnd" }) {
  const replayRequestedRef = useRef(false);
  const requestReplay = useCallback(() => {
    if (replayRequestedRef.current) return;

    replayRequestedRef.current = true;
    onReplay();
  }, [onReplay]);

  if (mode === "foodOrdersEnd") return <SmartBarDemoFoodOrdersEndScreen />;

  return (
    <main className="relative h-[100svh] min-h-[100svh] overflow-hidden bg-[radial-gradient(circle_at_18%_12%,_rgba(56,189,248,0.22),_transparent_34%),radial-gradient(circle_at_88%_78%,_rgba(59,130,246,0.18),_transparent_32%),linear-gradient(135deg,_#eff8ff_0%,_#dff0ff_48%,_#f8fbff_100%)] text-slate-950">
      <div className="pointer-events-none absolute inset-0 opacity-[0.16] [background-image:linear-gradient(rgba(15,23,42,0.08)_1px,transparent_1px),linear-gradient(90deg,rgba(15,23,42,0.08)_1px,transparent_1px)] [background-size:44px_44px]" />
      <div className="pointer-events-none absolute -right-28 top-16 h-72 w-72 rounded-full bg-sky-300/22 blur-3xl" />
      <div className="pointer-events-none absolute -left-24 bottom-10 h-72 w-72 rounded-full bg-blue-300/20 blur-3xl" />

      <div className="pointer-events-auto absolute inset-0 z-10 flex items-center justify-center px-3">
        <motion.button
          type="button"
          onClick={(event) => {
            event.preventDefault();
            requestReplay();
          }}
          onPointerUp={(event) => {
            event.preventDefault();
            requestReplay();
          }}
          aria-label="Replay demo"
          title="Replay demo"
          initial={{ y: 36, opacity: 0, scale: 0.98 }}
          animate={{ y: 0, opacity: 1, scale: 1 }}
          transition={{
            duration: SMARTBAR_FLASH_CARD_TRANSITION_MS / 1000,
            ease: [0.22, 1, 0.36, 1],
          }}
          whileHover={{ y: -3 }}
          whileTap={{ scale: 0.985 }}
          className="group pointer-events-auto inline-flex min-h-[64px] w-fit max-w-[calc(100vw-1rem)] items-center gap-2 rounded-full border border-emerald-200/85 bg-gradient-to-b from-emerald-100/96 via-teal-100/90 to-emerald-50/84 px-3 py-2.5 text-left shadow-[inset_0_1px_0_rgba(255,255,255,0.95),inset_0_-1px_0_rgba(16,185,129,0.15),0_18px_45px_rgba(15,23,42,0.16)] ring-1 ring-emerald-200/75 backdrop-blur-xl transition sm:min-h-[72px] sm:gap-3 sm:px-5 sm:py-3.5"
        >
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-200/86 text-emerald-900 ring-1 ring-emerald-300/85 sm:h-12 sm:w-12">
            <RefreshCcw className="h-4 w-4 sm:h-5 sm:w-5" aria-hidden="true" />
          </span>

          <span className="min-w-0">
            <span className="block truncate text-sm font-black tracking-tight text-slate-950 sm:text-base">Demo complete</span>
            <span className="block truncate text-xs font-semibold text-slate-600">Refresh page to replay.</span>
          </span>

          <span className="ml-1 flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-slate-950 text-white shadow-lg shadow-slate-950/12 transition group-hover:bg-slate-800 sm:h-12 sm:w-auto sm:px-5 sm:text-xs sm:font-black sm:uppercase sm:tracking-[0.14em]">
            <RefreshCcw className="h-4 w-4 sm:hidden" aria-hidden="true" />
            <span className="hidden sm:inline">Replay</span>
          </span>
        </motion.button>
      </div>
    </main>
  );
}

function SmartBarMobilePlacementIntro({ onComplete }: { onComplete: () => void }) {
  useEffect(() => {
    const timer = window.setTimeout(onComplete, 5600);
    return () => window.clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="pointer-events-none absolute inset-0 z-20 overflow-hidden text-slate-950">
      <div className="absolute inset-x-6 top-[18%] text-center">
        <motion.div
          initial={{ y: 18, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.42, ease: "easeOut" }}
          className="text-[11px] font-black uppercase tracking-[0.22em] text-sky-700/70"
        >
          Mobile placement
        </motion.div>
        <motion.div
          initial={{ y: 18, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.18, duration: 0.42, ease: "easeOut" }}
          className="mx-auto mt-3 max-w-[320px] text-3xl font-black leading-tight tracking-tight text-slate-950"
        >
          SmartBar lives where thumbs already are.
        </motion.div>
      </div>

      <div className="absolute inset-x-0 bottom-[74px] flex justify-center px-4">
        <motion.div
          initial={{ width: 188, height: 54, borderRadius: 999, y: 18, opacity: 0 }}
          animate={{
            width: [188, 188, 322, 322, 188],
            height: [54, 54, 98, 98, 54],
            borderRadius: [999, 999, 30, 30, 999],
            y: 0,
            opacity: 1,
          }}
          transition={{
            y: { duration: 0.42, ease: "easeOut" },
            opacity: { duration: 0.42, ease: "easeOut" },
            width: { duration: 4.8, times: [0, 0.22, 0.46, 0.76, 1], ease: "easeInOut" },
            height: { duration: 4.8, times: [0, 0.22, 0.46, 0.76, 1], ease: "easeInOut" },
            borderRadius: { duration: 4.8, times: [0, 0.22, 0.46, 0.76, 1], ease: "easeInOut" },
          }}
          className="relative overflow-hidden border border-white/70 bg-white/72 shadow-[inset_0_1px_0_rgba(255,255,255,0.92),0_24px_70px_rgba(15,23,42,0.22)] ring-1 ring-sky-200/80 backdrop-blur-2xl"
        >
          <motion.div
            initial={{ opacity: 1 }}
            animate={{ opacity: [1, 1, 0, 0, 1] }}
            transition={{ duration: 4.8, times: [0, 0.24, 0.38, 0.78, 1], ease: "easeInOut" }}
            className="absolute inset-0 flex items-center justify-center gap-2 px-5"
          >
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-950 text-xs font-black text-white shadow-lg">S</span>
            <span className="text-sm font-black tracking-tight text-slate-950">SmartBar</span>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0, 1, 1, 0] }}
            transition={{ duration: 4.8, times: [0, 0.34, 0.48, 0.78, 1], ease: "easeInOut" }}
            className="absolute inset-0 flex flex-col items-center justify-center px-5 text-center"
          >
            <div className="text-[11px] font-black uppercase tracking-[0.16em] text-sky-700/70">Tap opens input</div>
            <div className="mt-1 text-base font-black leading-tight text-slate-950">Say the order in plain English</div>
          </motion.div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, scale: 0.82, y: 18 }}
        animate={{ opacity: [0, 1, 1, 0], scale: [0.82, 1, 0.92, 0.92], y: [18, 0, 0, 0] }}
        transition={{ duration: 2.1, delay: 0.92, times: [0, 0.34, 0.72, 1], ease: "easeOut" }}
        className="absolute bottom-[118px] left-1/2 z-30 h-12 w-12 -translate-x-1/2 rounded-full border border-sky-200 bg-white/92 shadow-2xl shadow-slate-950/18 ring-4 ring-sky-300/30"
      />
    </div>
  );
}

function SmartBarMobileDemoBackdrop({ children }: { children?: any }) {
  return (
    <main className="relative h-[100svh] min-h-[100svh] overflow-hidden bg-[radial-gradient(circle_at_18%_12%,_rgba(56,189,248,0.22),_transparent_34%),radial-gradient(circle_at_88%_78%,_rgba(59,130,246,0.18),_transparent_32%),linear-gradient(135deg,_#eff8ff_0%,_#dff0ff_48%,_#f8fbff_100%)] text-slate-950">
      <div className="pointer-events-none absolute inset-0 opacity-[0.16] [background-image:linear-gradient(rgba(15,23,42,0.08)_1px,transparent_1px),linear-gradient(90deg,rgba(15,23,42,0.08)_1px,transparent_1px)] [background-size:44px_44px]" />
      <div className="pointer-events-none absolute -right-28 top-16 h-72 w-72 rounded-full bg-sky-300/22 blur-3xl" />
      <div className="pointer-events-none absolute -left-24 bottom-10 h-72 w-72 rounded-full bg-blue-300/20 blur-3xl" />
      {children}
    </main>
  );
}





export type SmartBarSpeedDemoVariant = "full" | "burgerRushOnly" | "foodTrioDesktop";

type CheckoutThinkingOverlayState = {
  id: number;
  message: string;
  rect: {
    top: number;
    left: number;
    width: number;
    height: number;
  };
};

function SmartBarCheckoutThinkingOverlay({ overlay }: { overlay: CheckoutThinkingOverlayState | null }) {
  return (
    <AnimatePresence>
      {overlay ? (
        <motion.div
          key={overlay.id}
          initial={{ opacity: 0, scale: 0.998 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.998 }}
          transition={{ duration: 0.12, ease: "easeOut" }}
          style={{
            top: overlay.rect.top,
            left: overlay.rect.left,
            width: overlay.rect.width,
            height: overlay.rect.height,
          }}
          className="pointer-events-none fixed z-[10145] inline-flex items-center justify-center gap-1.5 rounded-full bg-white px-4 py-2.5 text-sm font-black text-[#17227c] shadow-[inset_0_1px_0_rgba(255,255,255,0.72),0_10px_24px_rgba(15,23,42,0.18)] ring-1 ring-white/70"
        >
          {/* FOODTRIO_CHECKOUT_REAL_THINKING_LABEL_V1:
              Use the same training-animation label treatment. No dots,
              no new wording — the Checkout label itself thinks. */}
          <ThinkingText body={overlay.message || "Checkout"} />
        </motion.div>
      ) : null}
    </AnimatePresence>
  );
}

export default function SmartBarSpeedDemo({
  autoPlay = false,
  variant = "full",
}: {
  autoPlay?: boolean;
  variant?: SmartBarSpeedDemoVariant;
}) {
  const [stepIndex, setStepIndex] = useState(-1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [demoCommand, setDemoCommand] = useState<TourBarShellDemoCommand | null>(null);
  const [activeTutorLane, setActiveTutorLane] = useState<SmartBarFlashCardLaneName | null>(null);
  const [tutorNoticeA, setTutorNoticeA] = useState<SmartBarFlashCardNotice | null>(null);
  const [tutorNoticeB, setTutorNoticeB] = useState<SmartBarFlashCardNotice | null>(null);
  const [activeTutorStackMode, setActiveTutorStackMode] = useState<SmartBarFlashCardCascadeMode>("standard");
  const [tutorStackCards, setTutorStackCards] = useState<SmartBarFlashCardStackItem[]>([]);
  const [tutorBlocking, setTutorBlocking] = useState(true);
  const [introRunId, setIntroRunId] = useState(0);
  const [fakePointer, setFakePointer] = useState<SmartBarFakePointerState | null>(null);
  const [checkoutThinkingOverlay, setCheckoutThinkingOverlay] = useState<CheckoutThinkingOverlayState | null>(null);
  const [replayVisible, setReplayVisible] = useState(false);
  const [mobileBurgerRushStage, setMobileBurgerRushStage] = useState<MobileBurgerRushStage>("intro");
  const [mobileNexaIntroReady, setMobileNexaIntroReady] = useState(false);
  const commandIdRef = useRef(0);
  const fakePointerIdRef = useRef(0);
  const targetStageRef = useRef<HTMLDivElement | null>(null);
  const lastAutoRevealTargetRef = useRef<{ targetId: string; at: number } | null>(null);
  const autoPlayStartedRef = useRef(false);
  const replayStartPendingRef = useRef(false);
  const replayFallbackTimerRef = useRef<number | null>(null);
  const mobileDomiRouteHandoffStartedRef = useRef(false);
  const primaryDraftRef = useRef("");
  const followUpDraftRef = useRef("");
  const mobileBurgerRushShell = variant === "burgerRushOnly" && speedDemoIsPhoneViewport();
  const mobileFullShell = variant === "full" && speedDemoIsPhoneViewport();
  const desktopFullMobileShell = variant === "full" && !speedDemoIsPhoneViewport();
  const generalFullMobileShell = mobileFullShell || desktopFullMobileShell;
  const directMobileShell = mobileBurgerRushShell || generalFullMobileShell;
  useEffect(() => {
    if (!generalFullMobileShell) {
      setMobileNexaIntroReady(true);
      return;
    }

    setMobileNexaIntroReady(false);

    const timer = window.setTimeout(() => {
      setMobileNexaIntroReady(true);
    }, 1050);

    return () => window.clearTimeout(timer);
  }, [generalFullMobileShell]);

  const demoSteps = useMemo(
    () => {
      if (variant === "foodTrioDesktop") return SMARTBAR_FOOD_TRIO_DESKTOP_STEPS;
      if (variant !== "burgerRushOnly") return SMARTBAR_SPEED_STEPS;
      return mobileBurgerRushShell ? SMARTBAR_BURGERRUSH_MOBILE_STEPS : SMARTBAR_BURGERRUSH_ONLY_STEPS;
    },
    [mobileBurgerRushShell, variant],
  );
  const openingTutorCards = variant === "burgerRushOnly" ? BURGERRUSH_ONLY_DEMO_TUTOR_CARDS : variant === "foodTrioDesktop" ? FOOD_TRIO_DESKTOP_OPENING_TUTOR_CARDS : OPENING_DEMO_TUTOR_CARDS;
  const effectiveAutoPlay = autoPlay && !mobileBurgerRushShell && (!generalFullMobileShell || mobileNexaIntroReady);
  useLayoutEffect(() => {
    if (!directMobileShell || typeof document === "undefined") return;

    const html = document.documentElement;
    const body = document.body;
    const root = document.getElementById("root");

    const previous = {
      htmlHeight: html.style.height,
      htmlMinHeight: html.style.minHeight,
      htmlOverflow: html.style.overflow,
      htmlOverflowX: html.style.overflowX,
      htmlOverflowY: html.style.overflowY,
      htmlOverscrollBehavior: html.style.overscrollBehavior,
      bodyHeight: body.style.height,
      bodyMinHeight: body.style.minHeight,
      bodyOverflow: body.style.overflow,
      bodyOverflowX: body.style.overflowX,
      bodyOverflowY: body.style.overflowY,
      bodyOverscrollBehavior: body.style.overscrollBehavior,
      bodyPosition: body.style.position,
      bodyTop: body.style.top,
      bodyLeft: body.style.left,
      bodyRight: body.style.right,
      bodyWidth: body.style.width,
      rootHeight: root?.style.height || "",
      rootMinHeight: root?.style.minHeight || "",
      rootOverflow: root?.style.overflow || "",
    };

    // BurgerRush mobile must behave like a normal web page. Earlier demo-mode
    // code froze html/body to protect the scripted stage, but this direct
    // mobile surface needs native document scrolling.
    html.style.height = "auto";
    html.style.minHeight = "100%";
    html.style.overflow = "";
    html.style.overflowX = "hidden";
    html.style.overflowY = "auto";
    html.style.overscrollBehavior = "auto";

    body.style.height = "auto";
    body.style.minHeight = "100%";
    body.style.overflow = "";
    body.style.overflowX = "hidden";
    body.style.overflowY = "auto";
    body.style.overscrollBehavior = "auto";
    body.style.position = "";
    body.style.top = "";
    body.style.left = "";
    body.style.right = "";
    body.style.width = "";

    if (root) {
      root.style.height = "auto";
      root.style.minHeight = "100%";
      root.style.overflow = "visible";
    }

    return () => {
      html.style.height = previous.htmlHeight;
      html.style.minHeight = previous.htmlMinHeight;
      html.style.overflow = previous.htmlOverflow;
      html.style.overflowX = previous.htmlOverflowX;
      html.style.overflowY = previous.htmlOverflowY;
      html.style.overscrollBehavior = previous.htmlOverscrollBehavior;
      body.style.height = previous.bodyHeight;
      body.style.minHeight = previous.bodyMinHeight;
      body.style.overflow = previous.bodyOverflow;
      body.style.overflowX = previous.bodyOverflowX;
      body.style.overflowY = previous.bodyOverflowY;
      body.style.overscrollBehavior = previous.bodyOverscrollBehavior;
      body.style.position = previous.bodyPosition;
      body.style.top = previous.bodyTop;
      body.style.left = previous.bodyLeft;
      body.style.right = previous.bodyRight;
      body.style.width = previous.bodyWidth;
      if (root) {
        root.style.height = previous.rootHeight;
        root.style.minHeight = previous.rootMinHeight;
        root.style.overflow = previous.rootOverflow;
      }
    };
  }, [directMobileShell]);

  const sendCommand = useCallback((command: Omit<TourBarShellDemoCommand, "id">) => {
    commandIdRef.current += 1;
    setDemoCommand({ id: commandIdRef.current, ...command });
  }, []);

  const clearReplayFallbackTimer = useCallback(() => {
    if (replayFallbackTimerRef.current === null) return;

    window.clearTimeout(replayFallbackTimerRef.current);
    replayFallbackTimerRef.current = null;
  }, []);

  const restartDemo = useCallback(() => {
    clearReplayFallbackTimer();
    setReplayVisible(false);
    setIsPlaying(false);
    setStepIndex(-1);
    setTutorBlocking(true);
    setTutorStackCards([]);
    setActiveTutorLane(null);
    setTutorNoticeA(null);
    setTutorNoticeB(null);
    setFakePointer(null);
    primaryDraftRef.current = "";
    followUpDraftRef.current = "";
    clearSmartBarFocusOverlay();
    resetSpeedDemoStageToTop(targetStageRef.current);
    sendCommand({ type: "closeAll" });

    if (mobileBurgerRushShell) {
      autoPlayStartedRef.current = false;
      replayStartPendingRef.current = false;
      setMobileBurgerRushStage("intro");
      setIntroRunId((runId) => runId + 1);
      return;
    }

    replayStartPendingRef.current = true;
    setIntroRunId((runId) => runId + 1);

    replayFallbackTimerRef.current = window.setTimeout(() => {
      if (!replayStartPendingRef.current) return;

      replayStartPendingRef.current = false;
      replayFallbackTimerRef.current = null;
      setTutorBlocking(false);
      setTutorStackCards([]);
      setActiveTutorLane(null);
      setTutorNoticeA(null);
      setTutorNoticeB(null);
      resetSpeedDemoStageToTop(targetStageRef.current);
      setStepIndex(0);
      setIsPlaying(true);
    }, 9000);
  }, [clearReplayFallbackTimer, mobileBurgerRushShell, sendCommand]);

  useEffect(() => {
    resetSpeedDemoStageToTop(targetStageRef.current);
  }, []);

  useEffect(() => () => {
    clearReplayFallbackTimer();
  }, [clearReplayFallbackTimer]);

  useEffect(() => {
    if (!effectiveAutoPlay || autoPlayStartedRef.current) return;

    autoPlayStartedRef.current = true;
    setReplayVisible(false);
    setStepIndex(0);
    setIsPlaying(true);
  }, [effectiveAutoPlay]);

  useEffect(() => {
    if (!mobileBurgerRushShell || mobileBurgerRushStage !== "demo" || !autoPlay || autoPlayStartedRef.current) return;

    autoPlayStartedRef.current = true;
    setReplayVisible(false);
    setTutorBlocking(false);
    resetSpeedDemoStageToTop(targetStageRef.current);
    setStepIndex(0);
    setIsPlaying(true);
  }, [autoPlay, mobileBurgerRushShell, mobileBurgerRushStage]);

  useEffect(() => {
    if (variant === "foodTrioDesktop") {
      setTutorBlocking(false);
      setTutorStackCards([]);
      setActiveTutorLane(null);
      setTutorNoticeA(null);
      setTutorNoticeB(null);
      return;
    }

    if (mobileBurgerRushShell && mobileBurgerRushStage !== "intro") {
      setTutorBlocking(false);
      setTutorStackCards([]);
      setActiveTutorLane(null);
      setTutorNoticeA(null);
      setTutorNoticeB(null);
      return;
    }

    let cancelled = false;

    const runOpeningTutorCards = async () => {
      setTutorBlocking(true);
      await wait(DEMO_TUTOR_INITIAL_DELAY_MS);
      if (cancelled) return;

      let nextLane: SmartBarFlashCardLaneName = "a";
      let activeCascadeGroup: string | null = null;

      for (let index = 0; index < openingTutorCards.length; index += 1) {
        const card = openingTutorCards[index];
        const notice: SmartBarFlashCardNotice = {
          variant: "prelude",
          title: card.title,
          detail: card.detail,
        };

        if (card.cascadeGroup) {
          const mode = card.cascadeMode || "standard";

          if (activeCascadeGroup && activeCascadeGroup !== card.cascadeGroup) {
            setTutorStackCards([]);
            await wait(SMARTBAR_FLASH_CARD_CROSSOVER_MS);
            if (cancelled) return;
          }

          if (activeCascadeGroup !== card.cascadeGroup) {
            setActiveTutorLane(null);
            setTutorStackCards([]);
            setActiveTutorStackMode(mode);
            activeCascadeGroup = card.cascadeGroup;
          }

          const stackItem: SmartBarFlashCardStackItem = {
            ...notice,
            id: `${card.cascadeGroup}-${index}`,
            density: card.density || (mode === "flurry" ? "micro" : "compact"),
          };

          setTutorStackCards((items) => [...items, stackItem]);
          await wait(card.holdMs ?? (mode === "flurry" ? FLASHCARD_SPEED_CONTROLS.rapidCascadeNextCardMs : FLASHCARD_SPEED_CONTROLS.slowCascadeNextCardMs));
          if (cancelled) return;

          if (card.clearCascade) {
            setTutorStackCards([]);
            activeCascadeGroup = null;
            await wait(SMARTBAR_FLASH_CARD_CROSSOVER_MS);
            if (cancelled) return;
          }

          continue;
        }

        if (activeCascadeGroup) {
          setTutorStackCards([]);
          activeCascadeGroup = null;
          await wait(SMARTBAR_FLASH_CARD_CROSSOVER_MS);
          if (cancelled) return;
        }

        if (nextLane === "a") setTutorNoticeA(notice);
        else setTutorNoticeB(notice);

        setActiveTutorLane(nextLane);
        await wait(SMARTBAR_FLASH_CARD_TRANSITION_MS + (card.holdMs ?? FLASHCARD_SPEED_CONTROLS.normalCardHoldMs));
        if (cancelled) return;

        nextLane = nextLane === "a" ? "b" : "a";
      }

      setActiveTutorLane(null);
      setTutorStackCards([]);
      await wait(SMARTBAR_FLASH_CARD_TRANSITION_MS);
      if (cancelled) return;

      setTutorBlocking(false);

      if (mobileBurgerRushShell) {
        setMobileBurgerRushStage("placement");
        return;
      }

      if (replayStartPendingRef.current) {
        replayStartPendingRef.current = false;
        clearReplayFallbackTimer();
        resetSpeedDemoStageToTop(targetStageRef.current);
        setStepIndex(0);
        setIsPlaying(true);
      }
    };

    void runOpeningTutorCards();

    return () => {
      cancelled = true;
    };
  }, [clearReplayFallbackTimer, introRunId, mobileBurgerRushShell, mobileBurgerRushStage, openingTutorCards, variant]);

  const completeMobilePlacementIntro = useCallback(() => {
    if (!mobileBurgerRushShell) return;

    setTutorBlocking(false);
    setTutorStackCards([]);
    setActiveTutorLane(null);
    setTutorNoticeA(null);
    setTutorNoticeB(null);
    resetSpeedDemoStageToTop(targetStageRef.current);
    setMobileBurgerRushStage("demo");
  }, [directMobileShell]);

  useEffect(() => {
    if (!mobileBurgerRushShell || mobileBurgerRushStage !== "outro") return;

    let cancelled = false;

    const runMobileOutroCards = async () => {
      setTutorBlocking(true);
      setActiveTutorLane(null);
      setTutorNoticeA(null);
      setTutorNoticeB(null);
      setTutorStackCards([]);
      setActiveTutorStackMode("standard");
      await wait(DEMO_TUTOR_INITIAL_DELAY_MS);
      if (cancelled) return;

      for (let index = 0; index < MOBILE_BURGERRUSH_OUTRO_TUTOR_CARDS.length; index += 1) {
        const card = MOBILE_BURGERRUSH_OUTRO_TUTOR_CARDS[index];
        setTutorStackCards((items) => [
          ...items,
          {
            id: `burger-rush-mobile-outro-${index}`,
            variant: "prelude",
            title: card.title,
            detail: card.detail,
            density: card.density || "normal",
          },
        ]);
        await wait(card.holdMs ?? FLASHCARD_SPEED_CONTROLS.slowCascadeNextCardMs);
        if (cancelled) return;

        if (card.clearCascade) {
          setTutorStackCards([]);
          await wait(SMARTBAR_FLASH_CARD_CROSSOVER_MS);
          if (cancelled) return;
        }
      }

      setTutorStackCards([]);
      setTutorBlocking(false);
      await wait(SMARTBAR_FLASH_CARD_TRANSITION_MS);
      if (cancelled) return;

      setReplayVisible(true);
    };

    void runMobileOutroCards();

    return () => {
      cancelled = true;
    };
  }, [mobileBurgerRushShell, mobileBurgerRushStage]);

  const showScriptCards = useCallback(
    async (
      command: Extract<SmartBarSpeedCommand, { kind: "cards" }>,
      cancelled: () => boolean,
    ) => {
      if (!command.cards.length) return;

      const mode = command.mode || "standard";
      const defaultDensity = command.density || (mode === "flurry" ? "compact" : "normal");
      const defaultGapMs = command.holdMs ?? (
        mode === "flurry"
          ? FLASHCARD_SPEED_CONTROLS.rapidCascadeNextCardMs
          : FLASHCARD_SPEED_CONTROLS.slowCascadeNextCardMs
      );
      const finalHoldMs = command.finalHoldMs ?? (
        mode === "flurry"
          ? FLASHCARD_SPEED_CONTROLS.rapidCascadeFinalHoldMs
          : FLASHCARD_SPEED_CONTROLS.slowCascadeFinalHoldMs
      );
      const runStamp = `${Date.now()}-${Math.round(performance.now())}`;

      setActiveTutorLane(null);
      setTutorNoticeA(null);
      setTutorNoticeB(null);
      setTutorStackCards([]);
      setActiveTutorStackMode(mode);

      await waitForFrame();
      if (cancelled()) return;

      for (let index = 0; index < command.cards.length; index += 1) {
        const card = command.cards[index];
        const isTextCard = typeof card === "string";
        const title = isTextCard ? card : card.title;
        const detail = isTextCard ? undefined : card.detail;
        const density = isTextCard ? defaultDensity : card.density || defaultDensity;
        const waitMs = isTextCard
          ? (index === command.cards.length - 1 ? finalHoldMs : defaultGapMs)
          : card.holdMs ?? (index === command.cards.length - 1 ? finalHoldMs : defaultGapMs);

        setTutorStackCards((items) => [
          ...items,
          {
            id: `script-card-${runStamp}-${index}`,
            variant: "prelude",
            title,
            detail,
            density,
          },
        ]);

        await wait(waitMs);
        if (cancelled()) return;
      }

      setTutorStackCards([]);
      await wait(SMARTBAR_FLASH_CARD_CROSSOVER_MS);
    },
    [],
  );

  const showCheckoutThinkingOverlay = useCallback(
    async (
      command: Extract<SmartBarSpeedCommand, { kind: "checkoutThinkingOverlay" }>,
      cancelled: () => boolean,
    ) => {
      const stage = targetStageRef.current;
      const durationMs = Math.min(2500, Math.max(2000, command.durationMs ?? 2250));
      let target: HTMLElement | null = null;

      for (let attempt = 0; attempt < 14; attempt += 1) {
        target = findSpeedDemoPointerTarget(stage, undefined, command.targetSelector);
        if (target && speedDemoElementLooksVisible(target)) break;
        target = null;
        await wait(80);
        if (cancelled()) return;
      }

      if (!target) return;

      await scrollSpeedDemoOverflowAncestorToTarget(target);
      await waitForSpeedDemoStableRect(target);
      if (cancelled() || !speedDemoElementLooksVisible(target)) return;

      const rect = target.getBoundingClientRect();
      const overlayId = Date.now();

      setCheckoutThinkingOverlay({
        id: overlayId,
        message: command.message || "Checkout",
        rect: {
          top: rect.top,
          left: rect.left,
          width: rect.width,
          height: rect.height,
        },
      });

      await wait(durationMs);

      setCheckoutThinkingOverlay((current) => (current?.id === overlayId ? null : current));

      if (cancelled()) return;

      if (command.clickAfter !== false) {
        await wait(70);
        if (cancelled()) return;
        target.click();
      }

      await wait(90);
    },
    [],
  );

  const showPointerClick = useCallback(
    async (
      command: Extract<SmartBarSpeedCommand, { kind: "pointerClick" }>,
      cancelled: () => boolean,
    ) => {
      const stage = targetStageRef.current;
      const mobileNextMovePointer = speedDemoIsMobileNextMovePointer(command);

      if (mobileNextMovePointer) {
        await wait(MOBILE_NEXT_MOVE_POINTER_EXTRA_WAIT_MS);
        if (cancelled()) return;
      }

      const target = await lockSpeedDemoPointerTarget(stage, command, cancelled);

      if (cancelled() || !target) return;

      await waitForSpeedDemoStableRect(target);
      if (cancelled() || !speedDemoTargetIsReady(stage, target)) return;

      const pointerId = fakePointerIdRef.current + 1;
      fakePointerIdRef.current = pointerId;

      setFakePointer(
        makeSmartBarFakePointerState(target, {
          id: pointerId,
          label: command.label,
          anchorX: command.anchorX ?? 0.5,
          anchorY: speedDemoPointerAnchorY(target, command),
          offsetX: command.offsetX,
          offsetY: speedDemoPointerOffsetY(target, command),
        }),
      );

      await wait(command.aimMs ?? SMARTBAR_FAKE_POINTER_AIM_MS);
      if (cancelled()) return;

      setFakePointer((current) =>
        current?.id === pointerId
          ? {
              ...current,
              phase: "pulse",
            }
          : current,
      );

      await wait(
        mobileNextMovePointer
          ? Math.max(command.pulseMs ?? 0, MOBILE_NEXT_MOVE_POINTER_PULSE_MS)
          : command.pulseMs ?? SMARTBAR_FAKE_POINTER_PULSE_MS,
      );
      if (cancelled()) return;

      if (command.click) {
        target.click();
        await wait(80);
        if (cancelled()) return;
      }

      setFakePointer((current) => (current?.id === pointerId ? null : current));
      await wait(command.exitMs ?? SMARTBAR_FAKE_POINTER_EXIT_MS);
    },
    [],
  );

  const typeIntoShell = useCallback(
    async (field: "primary" | "followup" | "chat", value: string, cancelled: () => boolean) => {
      const visibleField = field === "followup" && speedDemoIsPhoneViewport() ? "primary" : field;
      const type = visibleField === "primary" ? "setPrimary" : visibleField === "followup" ? "setFollowUp" : "setChatDraft";
      const delayMs = speedDemoTypeDelayMs();

      if (field === "primary") primaryDraftRef.current = value;
      if (field === "followup") followUpDraftRef.current = value;
      if (visibleField === "primary") primaryDraftRef.current = value;

      sendCommand({ type, value: "" });
      await wait(80);

      for (let index = 1; index <= value.length; index += 1) {
        if (cancelled()) return;
        sendCommand({ type, value: value.slice(0, index) });
        await wait(delayMs);
      }
    },
    [sendCommand],
  );

  const typeIntoElement = useCallback(
    async (targetSelector: string, value: string, cancelled: () => boolean, clearFirst = true) => {
      let target: HTMLInputElement | HTMLTextAreaElement | null = null;

      for (let attempt = 0; attempt < 16; attempt += 1) {
        target = document.querySelector<HTMLInputElement | HTMLTextAreaElement>(targetSelector);
        if (target && speedDemoElementLooksVisible(target)) break;
        await wait(90);
        if (cancelled()) return;
      }

      if (!target) return;

      target.focus();
      if (clearFirst) {
        const proto = target instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        setter?.call(target, "");
        target.dispatchEvent(new Event("input", { bubbles: true }));
        target.dispatchEvent(new Event("change", { bubbles: true }));
        await wait(70);
      }

      const delayMs = speedDemoTypeDelayMs();

      for (let index = 1; index <= value.length; index += 1) {
        if (cancelled()) return;
        const nextValue = value.slice(0, index);
        const proto = target instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        setter?.call(target, nextValue);
        target.dispatchEvent(new Event("input", { bubbles: true }));
        target.dispatchEvent(new Event("change", { bubbles: true }));
        await wait(delayMs);
      }
    },
    [],
  );

  const mobileFullPointerCommand = useCallback(
    (command: Extract<SmartBarSpeedCommand, { kind: "pointerClick" }>): Extract<SmartBarSpeedCommand, { kind: "pointerClick" }> => {
      const selector = command.targetSelector || "";

      if (selector.includes("data-smartbar-launcher-hotspot")) {
        return {
          ...command,
          targetSelector: '[data-smartbar-mobile-launcher="true"], [data-smartbar-mobile-companion="true"]',
          click: true,
        };
      }

      if (selector.includes("data-smartbar-primary-submit") || selector.includes("data-smartbar-followup-submit")) {
        return {
          ...command,
          targetSelector: '[data-smartbar-mobile-submit="true"], [data-smartbar-mobile-companion="true"]',
          click: false,
        };
      }

      if (selector.includes('data-tourbar-order-cta="checkout"')) {
        return {
          ...command,
          targetSelector: '[data-smartbar-mobile-checkout="true"], [data-tourbar-order-cta="checkout"]',
          click: true,
        };
      }

      if (selector.includes('data-tourbar-booking-nav="next"')) {
        return {
          ...command,
          targetSelector: '[data-smartbar-mobile-generic-action="booking-nav-next"], [data-smartbar-mobile-generic-action="next-room"], [data-tourbar-booking-nav="next"]:not(:disabled)',
          click: true,
        };
      }

      if (selector.includes('data-tourbar-nextmove-query="__case_studies"')) {
        return {
          ...command,
          targetSelector: '[data-smartbar-mobile-generic-action="show-proof"], [data-smartbar-mobile-generic-action*="proof"], [data-smartbar-mobile-generic-action*="case"], [data-tourbar-nextmove-query="__case_studies"]',
          click: true,
        };
      }

      if (selector.includes('data-tourbar-sheet-panel="true"')) {
        return {
          ...command,
          targetSelector: '[data-smartbar-mobile-generic-action]:not([disabled]), [data-tourbar-sheet-panel="true"] button:not([aria-label]):not(:disabled)',
          click: true,
        };
      }

      return command;
    },
    [],
  );

  const openMobileFullEntry = useCallback(
    async (cancelled: () => boolean) => {
      const existingInput = document.querySelector<HTMLElement>('[data-smartbar-mobile-entry-input="true"]');
      if (existingInput && speedDemoElementLooksVisible(existingInput)) return;

      await showPointerClick(
        {
          kind: "pointerClick",
          targetSelector: '[data-smartbar-mobile-launcher="true"], [data-smartbar-mobile-companion="true"]',
          label: "",
          click: true,
          delayMs: 80,
          pulseMs: 720,
        },
        cancelled,
      );
      await wait(260);
    },
    [showPointerClick],
  );

  const runMobileFullCommand = useCallback(
    async (command: SmartBarSpeedCommand, cancelled: () => boolean) => {
      if (!generalFullMobileShell) return false;

      if (command.kind === "shell") {
        if (command.type === "open") {
          await openMobileFullEntry(cancelled);
        }

        if (command.settleMs) await wait(command.settleMs);
        return true;
      }

      if (command.kind === "typePrimary" || command.kind === "typeFollowUp") {
        await openMobileFullEntry(cancelled);
        if (cancelled()) return true;

        const value = command.value;
        primaryDraftRef.current = value;
        followUpDraftRef.current = value;
        await typeIntoElement('[data-smartbar-mobile-entry-input="true"]', value, cancelled, true);
        return true;
      }

      if (command.kind === "submitPrimary" || command.kind === "submitFollowUp") {
        const submittedValue = command.value ?? primaryDraftRef.current ?? followUpDraftRef.current;
        await wait(80);
        if (cancelled()) return true;

        const submitTarget = firstVisibleSpeedDemoElement(
          Array.from(
            document.querySelectorAll<HTMLElement>(
              '[data-smartbar-mobile-submit="true"], [data-smartbar-mobile-companion="true"]',
            ),
          ),
        );

        submitTarget?.click();
        await wait(80);
        if (cancelled()) return true;

        await wait(speedDemoFixtureThinkingMsForQuery(submittedValue) + SCRIPTED_SUBMIT_SETTLE_BUFFER_MS);
        return true;
      }

      if (command.kind === "typeInput") {
        await typeIntoElement(command.targetSelector, command.value, cancelled, command.clearFirst ?? true);
        return true;
      }

      if (command.kind === "pointerClick") {
        await showPointerClick(mobileFullPointerCommand(command), cancelled);
        return true;
      }

      if (
        command.kind === "typeChat" ||
        command.kind === "submitChat" ||
        command.kind === "openBookingContext" ||
        command.kind === "setBookingContext" ||
        command.kind === "selectBookingDate" ||
        command.kind === "setBookingGuestCount" ||
        command.kind === "commitBookingContext" ||
        command.kind === "showFixture"
      ) {
        await wait(command.delayMs ?? 0);
        if ("settleMs" in command && command.settleMs) await wait(command.settleMs);
        return true;
      }

      return false;
    },
    [generalFullMobileShell, mobileFullPointerCommand, openMobileFullEntry, showPointerClick, typeIntoElement],
  );


  const runCommand = useCallback(
    async (command: SmartBarSpeedCommand, cancelled: () => boolean) => {
      if (command.delayMs) await wait(command.delayMs);
      if (cancelled()) return;

      if (command.kind === "pause") return;

      if (generalFullMobileShell && command.kind !== "cards" && command.kind !== "focusTarget") {
        const handled = await runMobileFullCommand(command, cancelled);
        if (handled) return;
      }

      if (command.kind === "typePrimary") return typeIntoShell("primary", command.value, cancelled);
      if (command.kind === "typeFollowUp") return typeIntoShell("followup", command.value, cancelled);
      if (command.kind === "typeInput") return typeIntoElement(command.targetSelector, command.value, cancelled, command.clearFirst ?? true);
      if (command.kind === "typeChat") return typeIntoShell("chat", command.value, cancelled);
      if (command.kind === "submitPrimary") {
        const submittedValue = command.value ?? primaryDraftRef.current;
        sendCommand({ type: "submitPrimary", value: submittedValue });
        await wait(speedDemoFixtureThinkingMsForQuery(submittedValue) + SCRIPTED_SUBMIT_SETTLE_BUFFER_MS);
        return;
      }
      if (command.kind === "submitFollowUp") {
        const submittedValue = command.value ?? followUpDraftRef.current;
        sendCommand({ type: "submitFollowUp", value: submittedValue });
        await wait(speedDemoFixtureThinkingMsForQuery(submittedValue) + SCRIPTED_SUBMIT_SETTLE_BUFFER_MS);
        return;
      }
      if (command.kind === "submitChat") {
        sendCommand({ type: "submitChat", value: command.value });
        return;
      }
      if (command.kind === "openBookingContext") {
        sendCommand({ type: "openBookingContext", field: command.field });
        if (command.settleMs) await wait(command.settleMs);
        return;
      }
      if (command.kind === "setBookingContext") {
        sendCommand({ type: "setBookingContext", bookingContext: command.bookingContext });
        return;
      }
      if (command.kind === "selectBookingDate") {
        sendCommand({ type: "selectBookingDate", dateKind: command.dateKind, value: command.value });
        return;
      }
      if (command.kind === "setBookingGuestCount") {
        sendCommand({ type: "setBookingGuestCount", guestAdults: command.adults, guestChildren: command.children });
        return;
      }
      if (command.kind === "commitBookingContext") {
        sendCommand({ type: "commitBookingContext", field: command.field });
        return;
      }
      if (command.kind === "showFixture") {
        const result = fixtureResult(command.value);
        const thinkingMs = command.thinkingMs ?? 0;

        if (thinkingMs > 0 && speedResultAllowsThinkingTheater(result, command.value)) {
          sendCommand({
            type: "showThinking",
            value: command.thinkingMessage || "Choosing the right tool...",
          });
          await wait(thinkingMs);
          if (cancelled()) return;
        }

        sendCommand({ type: "showResult", result });
        if (command.settleMs) await wait(command.settleMs);
        return;
      }
      if (command.kind === "cards") {
        await showScriptCards(command, cancelled);
        return;
      }
      if (command.kind === "checkoutThinkingOverlay") {
        await showCheckoutThinkingOverlay(command, cancelled);
        return;
      }
      if (command.kind === "pointerClick") {
        await showPointerClick(command, cancelled);
        return;
      }
      if (command.kind === "focusTarget") {
        const recentAutoReveal = lastAutoRevealTargetRef.current;
        if (recentAutoReveal?.targetId === command.targetId && Date.now() - recentAutoReveal.at < 2600) {
          await wait(command.delayMs ?? 0);
          return;
        }

        const stage = targetStageRef.current;
        const stageTarget = stage
          ? await scrollSpeedDemoStageToTarget(stage, command.targetId)
          : null;
        if (cancelled()) return;

        await smartbarFocusTarget(
          {
            pageId: "smartbar-speed-demo",
            targetId: command.targetId,
            label: command.label,
          },
          {
            initialDelayMs: command.initialDelayMs ?? 40,
            attempts: Math.min(command.attempts ?? 10, 10),
            overlayDurationMs: command.overlayDurationMs ?? (speedDemoIsPhoneViewport() ? 3600 : 2800),
            scrollBehavior: speedDemoIsPhoneViewport() ? "smooth" : "auto",
            skipPlacementScroll: Boolean(stageTarget),
          },
        );
        return;
      }
      if (command.kind === "shell") {
        sendCommand({ type: command.type });
        if (command.settleMs) await wait(command.settleMs);
      }
    },
    [generalFullMobileShell, runMobileFullCommand, sendCommand, showCheckoutThinkingOverlay, showPointerClick, showScriptCards, typeIntoElement, typeIntoShell],
  );

  useEffect(() => {
    if (stepIndex < 0 || tutorBlocking || !isPlaying) return;

    let cancelled = false;
    const currentStep = demoSteps[stepIndex];
    if (!currentStep) return;

    const run = async () => {
      for (const command of currentStep.commands) {
        if (cancelled) return;
        await runCommand(command, () => cancelled);
      }

      if (!cancelled) {
        await wait(650);
        if (cancelled) return;
        if (stepIndex < demoSteps.length - 1) {
          setStepIndex((index) => Math.min(index + 1, demoSteps.length - 1));
        } else {
          setFakePointer(null);
          setTutorStackCards([]);
          setActiveTutorLane(null);
          setTutorNoticeA(null);
          setTutorNoticeB(null);
          clearSmartBarFocusOverlay();
          resetSpeedDemoStageToTop(targetStageRef.current);
          sendCommand({ type: "closeAll" });
          await wait(DEMO_REPLAY_SETTLE_MS);
          if (cancelled) return;

          if (mobileBurgerRushShell) {
            setIsPlaying(false);
            setMobileBurgerRushStage("outro");
            return;
          }

          setReplayVisible(true);
          setIsPlaying(false);
        }
      }
    };

    void run();

    return () => {
      cancelled = true;
    };
  }, [demoSteps, isPlaying, mobileBurgerRushShell, runCommand, sendCommand, stepIndex, tutorBlocking]);

  const beforeResultReveal = async (result: TourBarShellResult) => {
    const targetId = speedDemoResultTarget(result);
    if (!targetId) {
      await wait(180);
      return;
    }

    const stage = targetStageRef.current;
    const stageTarget = stage ? await scrollSpeedDemoStageToTarget(stage, targetId) : null;
    lastAutoRevealTargetRef.current = { targetId, at: Date.now() };

    await smartbarFocusTarget(
      {
        pageId: "smartbar-speed-demo",
        targetId,
        label: result.label || result.title,
      },
      {
        initialDelayMs: 40,
        attempts: 10,
        overlayDurationMs: speedDemoIsPhoneViewport() ? 3200 : 2200,
        scrollBehavior: speedDemoIsPhoneViewport() ? "smooth" : "auto",
        skipPlacementScroll: Boolean(stageTarget),
      },
    );

    await wait(180);
  };

  const focusFoodTrioOrderingTarget = useCallback(
    (target: TourBarOrderingFocusTarget) => {
      const targetId = String(target.targetId || "").trim();
      const targetSelector = target.targetSelector;
      if (!targetId && !targetSelector) return;

      void (async () => {
        const stage = targetStageRef.current;
        const stageTarget = stage && targetId
          ? await scrollSpeedDemoStageToTarget(stage, targetId)
          : null;

        await smartbarFocusTarget(
          {
            pageId: "smartbar-speed-demo",
            targetId: targetId || undefined,
            targetSelector,
            label: target.label,
          },
          {
            initialDelayMs: 40,
            attempts: 12,
            overlayDurationMs: speedDemoIsPhoneViewport() ? 3600 : 2800,
            scrollBehavior: speedDemoIsPhoneViewport() ? "smooth" : "auto",
            skipPlacementScroll: Boolean(stageTarget),
          },
        );
      })();
    },
    [],
  );

  const onPrimarySubmit = async (query: string, _context: TourBarShellTurnContext) => {
    const result = fixtureResult(query);
    await wait(speedDemoFixtureThinkingMs(result, query));
    return result;
  };

  const onFollowUpSubmit = async (query: string, _context: TourBarShellTurnContext) => {
    const result = fixtureResult(query);
    await wait(speedDemoFixtureThinkingMs(result, query));
    return result;
  };

  const currentStep = stepIndex >= 0 ? demoSteps[stepIndex] : null;
  const defaultSurface = variant === "burgerRushOnly" || variant === "foodTrioDesktop" ? "ordering" : "info";
  const toolbarSurface = currentStep?.surface || defaultSurface;
  const isFinaleSurface = toolbarSurface === "finale";

  useEffect(() => {
    if (!generalFullMobileShell || toolbarSurface !== "booking" || mobileDomiRouteHandoffStartedRef.current) return;

    mobileDomiRouteHandoffStartedRef.current = true;

    const timer = window.setTimeout(() => {
      window.location.assign("/local-smartbar-domi?from=mobile-full-demo&t=domi-handoff");
    }, 850);

    return () => window.clearTimeout(timer);
  }, [generalFullMobileShell, toolbarSurface]);

  useLayoutEffect(() => {
    clearSmartBarFocusOverlay();
    resetSpeedDemoStageToTop(targetStageRef.current);

    let secondFrame = 0;
    const firstFrame = window.requestAnimationFrame(() => {
      resetSpeedDemoStageToTop(targetStageRef.current);

      secondFrame = window.requestAnimationFrame(() => {
        resetSpeedDemoStageToTop(targetStageRef.current);
        targetStageRef.current?.setAttribute("data-smartbar-speed-last-scroll-reset", toolbarSurface);
      });
    });

    return () => {
      window.cancelAnimationFrame(firstFrame);
      if (secondFrame) window.cancelAnimationFrame(secondFrame);
    };
  }, [toolbarSurface]);

  const activeChromeVariant = variant === "foodTrioDesktop" ? "blueCoreGlass" : "default";
  const activeOrderReviewAppearance = "light";

  const smartBarNode = mobileBurgerRushShell || generalFullMobileShell ? null : (
    <TourBarShell
              appearance="light"
              chromeVariant={activeChromeVariant}
              primaryPlaceholder="Ask in plain English..."
              followUpPlaceholder="Ask a follow-up..."
              launcherTitle="SmartBar speed demo"
              launcherAriaLabel="Open SmartBar speed demo"
              resultEyebrow="SmartBar response"
              initialLoadingMessage="Choosing the right tool..."
              followUpLoadingMessage="Switching tools..."
              consultantChat={{
                enabled: true,
                title: "Talk to a consultant",
                placeholder: "Add anything else if needed...",
                autoStartMessage: "Context received — connecting consultant.",
                autoStartConsultantMessage: "Hi there — You’re interested in Copilots?",
                replyThinkingMessage: "Thinking...",
                replyConfirmationMessage: "Great, lets set up a chat!",
              }}
              demoCommand={demoCommand}
              onPrimarySubmit={onPrimarySubmit}
              onFollowUpSubmit={onFollowUpSubmit}
              beforeResultReveal={beforeResultReveal}
              renderResultExtras={(result, actions) => renderSpeedExtras(result, actions, activeOrderReviewAppearance, variant === "foodTrioDesktop", variant === "foodTrioDesktop" ? focusFoodTrioOrderingTarget : undefined)}
              renderMobileControls={renderMobileSpeedControls}
              buildThreadMessage={(result) => [result.title, result.body].filter(Boolean).join("\n")}
            />
  );


  if (generalFullMobileShell) {
    // Desktop intentionally falls through to the same parent-driven mobile
    // branch used by narrow phone view. Do not mount SmartBarMobileGeneralExperience
    // directly here; that creates a second demo/content driver.
    if (replayVisible) {
      return <SmartBarDemoReplayScreen onReplay={restartDemo} mode="replay" />;
    }

    if (!mobileNexaIntroReady) {
      return (
        <main className="relative min-h-[100svh] overflow-hidden bg-[#d9ecff] text-slate-950">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_18%,rgba(255,255,255,0.82),transparent_38%),radial-gradient(circle_at_18%_86%,rgba(125,211,252,0.34),transparent_38%),linear-gradient(180deg,#e8f5ff_0%,#d9ecff_48%,#c8e4ff_100%)]" />
        </main>
      );
    }

    const mobileCards = (
      <SmartBarFlashCardRail className="pointer-events-none !fixed !left-0 !right-0 !top-[33%] z-[10120] !w-full sm:!top-[31%] lg:!top-[32%]">
        <SmartBarFlashCardStack cards={tutorStackCards} mode={activeTutorStackMode} align="center" />
        <SmartBarFlashCardLane active={activeTutorLane === "a"} align="center">
          <SmartBarFlashCard notice={tutorNoticeA} />
        </SmartBarFlashCardLane>
        <SmartBarFlashCardLane active={activeTutorLane === "b"} align="center">
          <SmartBarFlashCard notice={tutorNoticeB} />
        </SmartBarFlashCardLane>
      </SmartBarFlashCardRail>
    );

    if (toolbarSurface === "booking") {
      return (
        <main className="relative min-h-[100svh] overflow-hidden bg-[#d9ecff] text-slate-950">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_18%,rgba(255,255,255,0.82),transparent_38%),radial-gradient(circle_at_18%_86%,rgba(125,211,252,0.34),transparent_38%),linear-gradient(180deg,#e8f5ff_0%,#d9ecff_48%,#c8e4ff_100%)]" />
        </main>
      );
    }

    const mobileSurfaceNode =
      toolbarSurface === "ordering" ? (
        <BurgerRushMobileExperience demoFixtureMode />
      ) : (
        <NexaPathMobileExperience demoFixtureMode />
      );

    return (
      <main className="relative min-h-[100svh] overflow-x-hidden bg-[#d9ecff] text-slate-950">
        {/* visible soft-blue Nexa intro veil */}
        <motion.div
          aria-hidden="true"
          initial={{ opacity: 1 }}
          animate={{ opacity: 0 }}
          transition={{ duration: 0.95, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="pointer-events-none fixed inset-0 z-[10110] bg-[radial-gradient(circle_at_50%_18%,rgba(255,255,255,0.82),transparent_38%),radial-gradient(circle_at_18%_86%,rgba(125,211,252,0.34),transparent_38%),linear-gradient(180deg,#e8f5ff_0%,#d9ecff_48%,#c8e4ff_100%)]"
        />
        <AnimatePresence mode="wait" initial={true}>
          <motion.div
            key={toolbarSurface}
            initial={{ opacity: 0, scale: 0.985, y: 14 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.965, y: -14 }}
            transition={{ duration: 0.58, ease: [0.22, 1, 0.36, 1] }}
            className="relative min-h-[100svh] origin-center"
          >
            {mobileSurfaceNode}
          </motion.div>
        </AnimatePresence>
        {mobileCards}
        <SmartBarFakePointerOverlay pointer={fakePointer} />
      </main>
    );
  }

  if (mobileBurgerRushShell) {
    if (replayVisible) {
      return <SmartBarDemoReplayScreen onReplay={restartDemo} mode="replay" />;
    }

    const mobileCards = (
      <SmartBarFlashCardRail className="pointer-events-none !fixed inset-x-0 !top-[34%] z-[10120]">
        <SmartBarFlashCardStack cards={tutorStackCards} mode={activeTutorStackMode} />
        <SmartBarFlashCardLane active={activeTutorLane === "a"}>
          <SmartBarFlashCard notice={tutorNoticeA} />
        </SmartBarFlashCardLane>
        <SmartBarFlashCardLane active={activeTutorLane === "b"}>
          <SmartBarFlashCard notice={tutorNoticeB} />
        </SmartBarFlashCardLane>
      </SmartBarFlashCardRail>
    );

    if (mobileBurgerRushStage !== "demo") {
      return (
        <SmartBarMobileDemoBackdrop>
          {mobileCards}
          {mobileBurgerRushStage === "placement" && (
            <SmartBarMobilePlacementIntro onComplete={completeMobilePlacementIntro} />
          )}
        </SmartBarMobileDemoBackdrop>
      );
    }

    return (
      <main className="relative min-h-[100svh] overflow-x-hidden bg-white text-slate-950">
        <BurgerRushMobileExperience demoFixtureMode />
        {mobileCards}
        <SmartBarFakePointerOverlay pointer={fakePointer} />
      </main>
    );
  }

  if (replayVisible) {
    return <SmartBarDemoReplayScreen onReplay={restartDemo} mode={variant === "foodTrioDesktop" ? "foodOrdersEnd" : "replay"} />;
  }

  return (
    <main className="relative h-[100svh] min-h-[100svh] overflow-hidden overscroll-none bg-[radial-gradient(circle_at_top_left,_rgba(14,165,233,0.14),_transparent_32%),radial-gradient(circle_at_bottom_right,_rgba(15,23,42,0.10),_transparent_34%),linear-gradient(135deg,_#f8fafc_0%,_#eef6ff_52%,_#f8fafc_100%)] text-slate-950">
      <div className="pointer-events-none absolute inset-0 opacity-[0.18] [background-image:linear-gradient(rgba(15,23,42,0.08)_1px,transparent_1px),linear-gradient(90deg,rgba(15,23,42,0.08)_1px,transparent_1px)] [background-size:44px_44px]" />

      <SmartBarFlashCardRail
        className={
          variant === "foodTrioDesktop"
            ? "pointer-events-none !fixed !left-0 !right-0 !top-[32%] z-[10120] !w-full lg:!top-[31%]"
            : "!top-[45%] sm:!top-1/2"
        }
      >
        <SmartBarFlashCardStack
          cards={tutorStackCards}
          mode={activeTutorStackMode}
          align={variant === "foodTrioDesktop" ? "center" : "end"}
        />
        <SmartBarFlashCardLane active={activeTutorLane === "a"} align={variant === "foodTrioDesktop" ? "center" : "end"}>
          <SmartBarFlashCard notice={tutorNoticeA} />
        </SmartBarFlashCardLane>
        <SmartBarFlashCardLane active={activeTutorLane === "b"} align={variant === "foodTrioDesktop" ? "center" : "end"}>
          <SmartBarFlashCard notice={tutorNoticeB} />
        </SmartBarFlashCardLane>
      </SmartBarFlashCardRail>

      <SmartBarFakePointerOverlay pointer={fakePointer} />
      {/* FOODTRIO_CHECKOUT_REAL_THINKING_LABEL_V1:
          Demo-level label layer over Checkout. The visible word "Checkout" uses
          the real ThinkingText animation for 2000-2500ms, then the real click fires. */}
      <SmartBarCheckoutThinkingOverlay overlay={checkoutThinkingOverlay} />

      <div className="relative z-[10070] px-4 pt-4 sm:px-6">
        {isFinaleSurface ? (
          <div className="mx-auto flex max-w-7xl justify-end">
            <div className="relative z-[10080] flex h-12 w-12 shrink-0 items-center justify-center sm:h-9 sm:w-9">
              {smartBarNode}
            </div>
          </div>
        ) : (
          <SmartBarDemoToolbarFrame
            surface={toolbarSurface}
            smartBarNode={smartBarNode}
            chromeVariant={activeChromeVariant}
          />
        )}
      </div>

      <div
        key={toolbarSurface}
        ref={targetStageRef}
        data-smartbar-speed-stage="true"
        data-smartbar-scroll-stage="true"
        data-smartbar-speed-surface={toolbarSurface}
        className={isFinaleSurface
          ? "relative z-10 h-[calc(100svh-106px)] overflow-hidden overscroll-none pb-32 pt-2"
          : mobileBurgerRushShell
            ? "relative z-10 h-[calc(100svh-106px)] overflow-y-auto overscroll-none pb-32 pt-2 [scrollbar-gutter:stable] [-webkit-overflow-scrolling:touch]"
            : "relative z-10 h-[calc(100svh-106px)] overflow-y-auto overscroll-contain pb-32 pt-2 [scrollbar-gutter:stable]"
        }
      >
        {/* FOODTRIO_FINALE_USES_NEUTRAL_TARGET_WALL:
            FoodTrio uses its restaurant target wall until the finale. On the
            finale surface, render the neutral finale wall so the FoodTrio page
            visibly tears down before finale cards run. */}
        <SmartBarSpeedTargetWall
          surface={toolbarSurface}
          variant={variant === "foodTrioDesktop" && !isFinaleSurface ? "foodTrioDesktop" : "standard"}
        />
      </div>


      {!mobileBurgerRushShell && <SmartBarDemoScrubber
        index={stepIndex}
        isPlaying={isPlaying}
        onSelect={(index) => {
          if (tutorBlocking) return;
          setReplayVisible(false);
          setIsPlaying(false);
          setStepIndex(index);
        }}
        onTogglePlay={() => {
          if (tutorBlocking) return;
          setReplayVisible(false);
          if (isPlaying) {
            setIsPlaying(false);
            return;
          }
          if (stepIndex < 0) setStepIndex(0);
          setIsPlaying(true);
        }}
      />}
    </main>
  );
}




