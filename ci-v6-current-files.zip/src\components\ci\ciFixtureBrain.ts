import type { ApexFixtureReply, ApexQuickStart } from "./ciChatTypes";

export const CI_QUICK_STARTS: ApexQuickStart[] = [
  {
    label: "Blocked tickets",
    prompt: "Show blocked tickets for the migration workstream.",
  },
  {
    label: "Project risks",
    prompt: "Summarize open risks for Project Phoenix.",
  },
  {
    label: "Status update",
    prompt: "Draft a status update for CI leadership.",
  },
  {
    label: "This week",
    prompt: "What changed this week across support and delivery?",
  },
];

const blockedTicketCards = [
  {
    eyebrow: "ServiceNow · INC-1842",
    title: "VPN latency affecting finance users",
    body:
      "Blocked on network vendor confirmation. 18 impacted users. Current owner: Infrastructure Ops.",
    meta: "Priority: P2 · SLA risk in 11h",
  },
  {
    eyebrow: "Jira · PHX-217",
    title: "Identity mapping incomplete for payroll app",
    body:
      "App owner approved the cutover, but two privileged groups still need validation before migration.",
    meta: "Owner: Maya Patel · Due tomorrow",
  },
  {
    eyebrow: "Task · SEC-044",
    title: "Conditional access exception review",
    body:
      "Security needs approval to retire three legacy exceptions tied to executive devices.",
    meta: "Owner: CI Security · Waiting on approval",
  },
];

const riskCards = [
  {
    eyebrow: "Risk register",
    title: "Identity cleanup is the critical path",
    body:
      "Most technical tasks are moving, but identity exceptions and owner validation are now the highest-risk lane.",
    meta: "Risk level: High",
  },
  {
    eyebrow: "Delivery signal",
    title: "Cutover date still looks possible",
    body:
      "The current blocker count is manageable if Security closes access exceptions before the next readiness review.",
    meta: "Confidence: Medium",
  },
];

const weeklyCards = [
  {
    eyebrow: "Support trend",
    title: "Escalations down 14%",
    body:
      "Most volume reduction came from fewer password reset and access request tickets after the self-service update.",
    meta: "Compared with prior week",
  },
  {
    eyebrow: "Delivery trend",
    title: "Two migration tasks slipped",
    body:
      "Both slips are tied to app-owner validation, not engineering capacity.",
    meta: "Needs stakeholder follow-up",
  },
  {
    eyebrow: "Leadership watch item",
    title: "Security review moved ahead",
    body:
      "The exception review is now the best candidate for leadership escalation because it unlocks multiple workstreams.",
    meta: "Recommended next action",
  },
];

function normalize(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

export function resolveCiFixtureReply(prompt: string): ApexFixtureReply {
  const text = normalize(prompt);

  if (text.includes("blocked") || text.includes("ticket") || text.includes("incident")) {
    return {
      title: "Blocked workstream summary",
      body:
        "I found three active blockers. The pattern is clear: the migration is not mainly blocked by build work — it is blocked by owner validation, access cleanup, and one vendor-dependent incident.",
      cards: blockedTicketCards,
      actions: [
        { label: "Draft escalation", prompt: "Draft an escalation note for these blockers." },
        { label: "Show owners", prompt: "Who owns each blocked ticket?" },
      ],
    };
  }

  if (text.includes("risk") || text.includes("phoenix") || text.includes("migration")) {
    return {
      title: "Project Phoenix risk readout",
      body:
        "Project Phoenix is still viable, but the risk has shifted from technical execution to decision latency. I would put identity cleanup and exception retirement at the top of the leadership review.",
      cards: riskCards,
      actions: [
        { label: "Leadership bullets", prompt: "Turn this into three leadership bullets." },
        { label: "Find blockers", prompt: "Show blocked tickets for Project Phoenix." },
      ],
    };
  }

  if (text.includes("status") || text.includes("leadership") || text.includes("draft")) {
    return {
      title: "Draft status update",
      body:
        "Draft: Project Phoenix remains on track with one major watch item. Engineering progress is steady, but identity validation and conditional access exceptions need leadership attention this week. Recommended ask: confirm app-owner signoff and approve exception retirement before the next readiness checkpoint.",
      cards: [
        {
          eyebrow: "Suggested send",
          title: "Leadership channel update",
          body:
            "On track overall. Main risk is not build completion; it is approvals around identity cleanup and security exceptions.",
          meta: "Tone: concise executive update",
        },
      ],
      actions: [
        { label: "Make sharper", prompt: "Make the leadership update more direct." },
        { label: "Add ask", prompt: "Add a clear executive ask to the update." },
      ],
    };
  }

  if (text.includes("changed") || text.includes("week") || text.includes("trend")) {
    return {
      title: "Weekly change summary",
      body:
        "The week improved operationally but got tighter from a governance standpoint. Support escalations are down, while migration risk is now concentrated in approvals and app-owner validation.",
      cards: weeklyCards,
      actions: [
        { label: "Exec summary", prompt: "Summarize this in executive language." },
        { label: "Next actions", prompt: "What should CI do next?" },
      ],
    };
  }

  if (text.includes("owner") || text.includes("who owns")) {
    return {
      title: "Ownership map",
      body:
        "The active ownership split is: Infrastructure Ops owns VPN latency, Maya Patel owns payroll identity mapping, and CI Security owns conditional access exception review. The fastest unlock is Security approval, because it clears multiple dependent tasks.",
      cards: blockedTicketCards.map((card) => ({
        ...card,
        eyebrow: card.eyebrow?.replace("ServiceNow · ", "Owner lookup · ").replace("Jira · ", "Owner lookup · ").replace("Task · ", "Owner lookup · "),
      })),
      actions: [
        { label: "Draft nudges", prompt: "Draft owner follow-up messages." },
        { label: "Escalate", prompt: "Draft an escalation note for CI leadership." },
      ],
    };
  }

  return {
    title: "CI command response",
    body:
      "I can work against the staged CI fixture set: tickets, owners, project risks, weekly support trends, and leadership updates. Try asking for blockers, risk summaries, ownership, or a draft status update.",
    cards: [
      {
        eyebrow: "Fixture data ready",
        title: "Current fixture domains",
        body:
          "Projects, incidents, support trends, owner mapping, and executive status updates are available in this PoC layer.",
        meta: "Local data only · No tenant access required",
      },
    ],
    actions: CI_QUICK_STARTS.slice(0, 3).map((item) => ({
      label: item.label,
      prompt: item.prompt,
    })),
  };
}
